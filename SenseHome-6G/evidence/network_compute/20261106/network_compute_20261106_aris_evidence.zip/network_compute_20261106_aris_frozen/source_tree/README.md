# Runnable Core Source Snapshot

This is the runnable network/compute/gateway experiment source tree, not the full
competition media/submission bundle. It preserves the project-relative layout.
Original implementation digests are in `../replay/summary.json`; historical tests
and backend sources copied after the run are separately labeled by
`../supplemental_source_snapshot.json`.

On the current Windows machine, the copied `policy_cli.exe` is the frozen
project-built executable. For other machines, build it with gcc/clang/tcc:

```powershell
gcc -std=c99 -Wall -Wextra -O2 -o SenseHome-6G/net_offload/policy_cli.exe `
  SenseHome-6G/net_offload/policy_cli.c SenseHome-6G/net_offload/offload_policy.c
```

Run tests from this `source_tree` directory:

```powershell
python -m unittest discover -s SenseHome-6G/net_offload/tests -q
python -m unittest discover -s openvela_smart_home/dashboard/tests -q
python -m unittest discover -s docs/deployment -q
```

The all-in-one suite requires an installed compiler (or `--compiler <path>`):

```powershell
python SenseHome-6G/net_offload/run_experiment_suite.py --out new_run
```

For a private PC simulation preview, set `SENSEHOME_STATE_FILE` and
`SENSEHOME_EVENT_LOG` to new writable files, then run:

```powershell
python openvela_smart_home/dashboard/bridge_server.py --port 8096 --patrol-interval 0
```

The server binds loopback by default. Configure model URLs explicitly; with no
model configured, only supported local commands execute. All model/network
fixtures remain explicitly synthetic and require no paid service.
