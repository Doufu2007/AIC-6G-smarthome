"""Background HTTP endpoint monitoring for the PC device simulator.

The device bridge is in this process, so LAN reachability is explicit rather
than inferred from the availability of a separate optional local model.
"""
import copy
import threading
import time


class BackendMonitor:
    def __init__(self, backends, interval_s=2.0):
        if interval_s <= 0:
            raise ValueError("monitor_interval_must_be_positive")
        self.backends = dict(backends)
        self.interval_s = interval_s
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self._refresh_lock = threading.Lock()
        self._sequence = 0
        self._history = {}
        self._latest = {'status': 'warming-up', 'backends': {}, 'sampled_at': None,
                        'link': {'wan_ok': False, 'wan_rtt_ms': None, 'lan_ok': True, 'lan_rtt_ms': 0.0},
                        'link_basis': 'HTTP endpoint RTT; devices simulated in gateway process'}

    def refresh_once(self):
        with self._refresh_lock:
            self._refresh()

    def _refresh(self):
        health = {}
        sampled = {}
        for name, backend in self.backends.items():
            begin = time.monotonic()
            try:
                health[name] = dict(backend.health())
            except Exception as exc:
                health[name] = {'ready': False, 'reachable': False, 'error': type(exc).__name__}
            sampled[name] = begin
            previous = self._history.get(name, {})
            ok = bool(health[name].get('reachable', False))
            rtt = health[name].get('latency_ms')
            last_rtt = previous.get('last_rtt')
            jitter = (previous.get('jitter', 0) * .875 + abs(rtt - last_rtt) * .125
                      if ok and isinstance(rtt, (float, int)) and last_rtt is not None else 0)
            outcomes = (previous.get('outcomes', []) + [int(not ok)])[-16:]
            self._history[name] = {'last_rtt': rtt if ok else None, 'jitter': jitter,
                                   'outcomes': outcomes}
            health[name]['observed_jitter_ms'] = jitter
            health[name]['observed_connection_failure_pct'] = 100 * sum(outcomes) / len(outcomes)
        cloud = health.get('cloud-model', {})
        self._sequence += 1
        latest = {'status': 'sampled', 'backends': health, 'sampled_at': time.time(),
                  'sampled_monotonic': time.monotonic(), 'endpoint_sampled_monotonic': sampled,
                  'observation_id': self._sequence,
                  'link': {'wan_ok': bool(cloud.get('reachable', False)),
                           'wan_rtt_ms': cloud.get('latency_ms'),
                           'lan_ok': True, 'lan_rtt_ms': 0.0},
                  'link_basis': self._latest['link_basis']}
        with self._lock:
            self._latest = latest

    def snapshot(self):
        with self._lock:
            snapshot = copy.deepcopy(self._latest)
        now = time.monotonic()
        sampled = snapshot.pop('sampled_monotonic', None)
        endpoint_times = snapshot.pop('endpoint_sampled_monotonic', {})
        snapshot['endpoint_age_ms'] = {
            name: round(max(0, now - value) * 1000, 3) for name, value in endpoint_times.items()}
        # Conservative whole-observation age starts at the first endpoint check.
        oldest = min(endpoint_times.values(), default=sampled)
        snapshot['age_ms'] = None if oldest is None else round(max(0, now - oldest) * 1000, 3)
        return snapshot

    def start(self):
        def run():
            while not self._stop.is_set():
                self.refresh_once()
                self._stop.wait(self.interval_s)
        self._thread = threading.Thread(target=run, daemon=True, name='sensehome-backend-monitor')
        self._thread.start()
        return self

    def close(self):
        self._stop.set()
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=2)
