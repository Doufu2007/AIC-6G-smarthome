from pathlib import Path
import json
import re
import shutil
import subprocess
import unittest


class WebPanelGatewayTests(unittest.TestCase):
    def test_panel_renders_gateway_route_and_latency_metadata(self):
        html = Path(__file__).resolve().parents[1].joinpath("web_panel.html").read_text(encoding="utf-8")
        self.assertIn("d.backend", html)
        self.assertIn("d.reason", html)
        self.assertIn("d.latency", html)
        self.assertIn("/api/health", html)

    def test_model_response_log_uses_text_nodes_not_executable_html(self):
        node = shutil.which("node")
        if node is None:
            self.skipTest("Node not installed; DOM fixture unavailable")
        html = Path(__file__).resolve().parents[1].joinpath("web_panel.html").read_text(encoding="utf-8")
        source = re.search(r"function appendLog\(.*?\n\}", html, re.S).group(0)
        script = r"""
const assert = require('node:assert/strict');
function element() {
  const node = {children: [], appendChild(c) {this.children.push(c)}};
  Object.defineProperty(node, 'innerHTML', {set() {throw new Error('UNTRUSTED_HTML')}});
  return node;
}
const log = element(), update = element();
const document = {createElement: element, getElementById(id) {return id === 'logContainer' ? log : update}};
SOURCE
const attack = '<img src=x onerror="fetch(\'/api/light\')">';
appendLog('answer', attack, attack);
assert.equal(log.children[0].children[0].textContent, attack);
assert.equal(log.children[0].children[1].textContent, attack);
"""
        result = subprocess.run([node, "-e", script.replace("SOURCE", source)], capture_output=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))


if __name__ == "__main__":
    unittest.main()
