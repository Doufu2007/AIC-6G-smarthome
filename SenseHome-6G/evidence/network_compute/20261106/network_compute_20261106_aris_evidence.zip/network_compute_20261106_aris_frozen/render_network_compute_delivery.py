"""Render the delivery report and evidence tables directly from frozen results."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def chart(path, entries, title, unit, max_value):
    width, height = 900, 100 + len(entries) * 42
    root = ET.Element("svg", {"xmlns": "http://www.w3.org/2000/svg",
                            "width": str(width), "height": str(height),
                            "viewBox": f"0 0 {width} {height}"})
    ET.SubElement(root, "rect", {"width": "900", "height": str(height), "fill": "#ffffff"})
    def text(x, y, content, size=15, color="#202a32"):
        element = ET.SubElement(root, "text", {"x": str(x), "y": str(y),
                 "font-family": "Arial,sans-serif", "font-size": str(size), "fill": color})
        element.text = content
    text(24, 33, title, 20)
    text(24, 58, unit + "; values from frozen raw JSON", 13, "#555555")
    colors = ("#187864", "#2263a3", "#bd4b53", "#907326", "#675591", "#56727a", "#383838")
    for index, (label, value) in enumerate(entries):
        y = 82 + index * 42
        text(24, y + 18, label)
        ET.SubElement(root, "rect", {"x": "260", "y": str(y), "width": f"{value / max_value * 500:.3f}",
                      "height": "26", "fill": colors[index % len(colors)]})
        text(775, y + 18, f"{value:.2f}")
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    run = args.run.resolve()
    output = run / "analysis"
    output.mkdir(exist_ok=True)
    replay = load(run / "replay/summary.json")
    concurrency = load(run / "concurrency/summary.json")
    sensitivity = load(run / "sensitivity/summary.json")
    safety = load(run / "safety/summary.json")
    verification = load(run / "validation/verification.json")
    http = load(run / "http_gateway/summary.json") if (run / "http_gateway/summary.json").exists() else None
    names = ("replay", "concurrency", "sensitivity", "safety") + (("http_gateway",) if http else ())
    for name in names:
        if not load(run / name / "audit.json")["passed"]:
            raise ValueError("UNVERIFIED_DELIVERY")
    if not verification["passed"]:
        raise ValueError("UNVERIFIED_BUILD")
    overall = [row for row in replay["statistics"]["overall"] if row["service"] == "interactive_inference"]
    by_arm = {row["arm"]: row for row in overall}
    concurrent_rows = []
    for group in concurrency["groups"]:
        for row in group["statistics"]["cells"]:
            if row["service"] == "interactive_inference":
                concurrent_rows.append({"concurrency": group["concurrency"], **row})
    fields = ("scenario", "service", "arm", "n", "p50_ms", "p95_ms", "p99_ms",
              "contract_completion_rate", "deadline_met_rate", "fallbacks", "p99_caution")
    write_csv(output / "experiment_matrix.csv", [
        {field: row[field] for field in fields} for row in replay["statistics"]["cells"]])
    write_csv(output / "concurrency_metrics.csv", [
        {field: row[field] for field in ("concurrency", *fields)} for row in concurrent_rows])
    failures = []
    for row in replay["statistics"]["cells"]:
        for error, count in row["failure_counts"].items():
            failures.append({key: row[key] for key in ("scenario", "service", "arm")} |
                            {"error": error, "count": count})
    write_csv(output / "failure_categories.csv", failures)
    switches = load(run / "replay/switches.json")
    priority = ("WAN_RTT_HIGH", "WAN_UNREACHABLE", "LOCAL_COMPUTE_OVERLOADED",
                "MODEL_UNAVAILABLE", "NO_MODEL_CAPACITY", "RECOVERY_HOLD", "COST_CLOUD", "LAN_DOWN")
    examples = []
    for reason in priority:
        example = next((item for item in switches if item["arm"] == "joint" and item["reason"] == reason), None)
        if example:
            examples.append(example)
    write_json(output / "switch_examples.json", examples)
    evidence = []
    for arm in ("joint", "network-only", "compute-only", "static-cloud", "no-hysteresis"):
        row = by_arm[arm]
        for metric in ("p50_ms", "p95_ms", "p99_ms", "contract_completion_rate", "deadline_met_rate"):
            evidence.append({
                "id": f"replay.interactive.{arm}.{metric}", "value": row[metric],
                "kind": "synthetic_trace_modeled_cost",
                "source": "replay/summary.json",
                "selector": f"statistics.overall[service=interactive_inference,arm={arm}].{metric}",
            })
    for row in concurrent_rows:
        for metric in ("p95_ms", "p99_ms", "contract_completion_rate", "deadline_met_rate"):
            evidence.append({
                "id": f"wallclock.c{row['concurrency']}.{row['scenario']}.{row['arm']}.{metric}",
                "value": row[metric], "kind": "measured_bounded_stub_PC_state",
                "source": "concurrency/summary.json",
                "selector": f"groups[concurrency={row['concurrency']}].statistics.cells[service=interactive_inference,scenario={row['scenario']},arm={row['arm']}].{metric}",
            })
    write_csv(output / "evidence_matrix.csv", evidence)
    if http:
        write_csv(output / "http_gateway_metrics.csv", [
            {field: row[field] for field in ("workload", "concurrency", *fields)} for row in http["cells"]])
        write_json(output / "http_switch_examples.json", load(run / "http_gateway/switches.json")[:30])
        for row in http["cells"]:
            if row["service"] != "interactive_inference":
                continue
            for metric in ("p50_ms", "p95_ms", "p99_ms", "deadline_met_rate", "contract_completion_rate"):
                evidence.append({
                    "id": f"http.{row['workload']}.c{row['concurrency']}.{row['scenario']}.{row['arm']}.{metric}",
                    "value": row[metric], "kind": "measured_default_HTTP_entry_contract_fixtures",
                    "source": "http_gateway/summary.json",
                    "selector": f"cells[workload={row['workload']},concurrency={row['concurrency']},scenario={row['scenario']},service=interactive_inference,arm={row['arm']}].{metric}",
                })
        write_csv(output / "evidence_matrix.csv", evidence)
    chart(output / "modeled_deadline.svg",
          [(row["arm"], row["deadline_met_rate"] * 100) for row in overall],
          "Synthetic Replay: Completed Within Deadline", "Percent; not physical 6G or model inference", 100)
    chart(output / "measured_concurrency.svg",
          [(f"c{row['concurrency']} {row['scenario']}", row["p95_ms"])
           for row in concurrent_rows if row["arm"] == "joint"],
          "Measured Wall Clock: Joint Policy p95", "Milliseconds; bounded sleep stubs, not AI/GPU inference",
          max(row["p95_ms"] for row in concurrent_rows) * 1.05)
    tests = {}
    import re
    for name in ("gateway", "dashboard", "deployment"):
        log = (run / f"validation/{name}_tests.txt").read_text(encoding="utf-8")
        match = re.search(r"Ran (\d+) tests?", log)
        tests[name] = int(match[1]) if match else 0
    counts = {name: load(run / name / "summary.json").get("raw_count",
              load(run / name / "summary.json").get("manifest", {}).get("raw_count", 0))
              for name in names}
    joint, cloud = by_arm["joint"], by_arm["static-cloud"]
    switch_counts = Counter(item["arm"] for item in switches)
    lines = [
        "# 网络—算力感知 AI 网关实验交付报告", "",
        f"运行日期：{verification['completed_utc'][:10]}（UTC）。事实源为本目录冻结 JSON，本文由脚本生成，不手填实验数字。", "",
        "## 结论", "",
        "已完成网络/算力输入、C 策略、白名单合同、回放、对照、消融、并发、敏感性、原始记录与独立复算闭环。",
        "家庭安全状态和结构化控制保持本地；模型/链路不可用时返回有原因码的降级，复杂任务无法完成会明确记失败。",
        "**本报告不是完整产品部署声明：没有新增真实模型推理、物理家居、家庭试点或真实 6G 空口数据。**", "",
        "## 交付与验证", "",
        f"- 原始记录：回放 {counts['replay']:,}；墙钟并发 {counts['concurrency']:,}；敏感性 {counts['sensitivity']:,}；白名单 {counts['safety']}。",
        f"- Python 测试：网关 {tests['gateway']}、Dashboard {tests['dashboard']}、部署 {tests['deployment']}，均通过。",
        "- C 原有测试：70 项策略断言与 17 项算力断言均通过；新增策略另外由真实 C CLI 集成测试覆盖。",
        f"- 白名单：{safety['rejected']} 个非法输入全部拒绝且状态未变；{safety['accepted_positive_controls']} 个正向合同通过。",
        f"- {len(replay['manifest']['trace_ids'])} 个回放 seed，{len(set(row['scenario'] for row in replay['statistics']['cells']))} 场景 × 3 业务画像 × 7 实验臂；严格共享逐请求输入。",
        "- 回放与 12 组参数扫描均再次调用 C，排除实测 IPC 波动后逐行一致。",
        "- 全部文件/源码哈希、矩阵、统计、失败口径、切换和队列回收已通过审计。", "",
        "## 回放结果：建模时延", "",
        f"下表只针对固定复杂规划合同。每臂 n={joint['n']:,}；失败与未理解均不能计为截止时间达标。",
        "各模型后端为合同桩；这些结果**不能**写成模型准确率或真实模型端到端时延。", "",
        "| 实验臂 | p50 ms | p95 ms | p99 ms | 合同完成 % | 截止时间达标 % |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in overall:
        lines.append(f"| {row['arm']} | {row['p50_ms']:.2f} | {row['p95_ms']:.2f} | {row['p99_ms']:.2f} | "
                     f"{row['contract_completion_rate']*100:.2f} | {row['deadline_met_rate']*100:.2f} |")
    lines += [
        "",
        f"联合策略相对静态云的达标率差值为 {(joint['deadline_met_rate']-cloud['deadline_met_rate'])*100:.2f} 个百分点，"
        "仅适用于本合成场景权重；不外推到真实家庭。",
        f"联合策略复杂任务切换 {switch_counts['joint']} 次，无滞回 {switch_counts['no-hysteresis']} 次；"
        "恢复更保守会略微牺牲部分恢复阶段的任务完成率，不宣称滞回在所有指标上占优。",
        "", "## 并发结果：实际墙钟", "",
        "每行 n=231 个复杂请求，来自三个重复；同一客户端闭环发起下一请求。",
        "下表的服务是固定 sleep 桩，执行是 PC 隔离状态，不是无线/GPU/真实家居容量。",
        "p99 样本量有限；应连同合同完成率、截止时间达标率阅读，拒答快不代表性能好。", "",
        "| 客户端 | 条件 | 实验臂 | p50 ms | p95 ms | p99 ms | 合同完成 % | 达标 % |",
        "|---:|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in concurrent_rows:
        lines.append(f"| {row['concurrency']} | {row['scenario']} | {row['arm']} | "
                     f"{row['p50_ms']:.2f} | {row['p95_ms']:.2f} | {row['p99_ms']:.2f} | "
                     f"{row['contract_completion_rate']*100:.2f} | {row['deadline_met_rate']*100:.2f} |")
    if http:
        lines += [
            "", "## 默认 HTTP 入口证据", "",
            f"新增 {http['raw_count']:,} 条客户端墙钟记录，实际使用默认初始化、`/api/command`、"
            "双端点 C 策略、HTTP 模型桩、白名单和隔离 JSON 状态；不是绕过业务入口的直接函数测试。",
            "客户端时间包含 HTTP 服务和事件持久化；`resource_observation` 保留两个端点的年龄与字段来源。",
            "捕获事件按 `decision_sequence` 再次提交 C，验证选择/原因一致；不是重新声称随机墙钟逐位一致。",
            "每臂共享配置轨迹，不共享完全相同的实测健康缓存，不对 HTTP 数据声称严格配对因果收益。",
            "", "| 客户端 | 条件 | 实验臂 | n | p50 ms | p95 ms | p99 ms | 合同完成 % | 达标 % |",
            "|---:|---|---|---:|---:|---:|---:|---:|---:|",
        ]
        for row in http["cells"]:
            if row["workload"] == "stress" and row["service"] == "interactive_inference":
                lines.append(f"| {row['concurrency']} | {row['scenario']} | {row['arm']} | {row['n']} | "
                             f"{row['p50_ms']:.2f} | {row['p95_ms']:.2f} | {row['p99_ms']:.2f} | "
                             f"{row['contract_completion_rate']*100:.2f} | {row['deadline_met_rate']*100:.2f} |")
        lines += [
            "", "默认业务入口已接线，但 HTTP 服务仍是固定规划桩；HTTP 延迟/503/体积延迟是应用层损伤注入。",
            "设备 LAN 当前是进程内模拟，不能把后端不可达写成真实设备 LAN 测量。",
            "network-only 已修为同一成本目标但去除算力健康/排队输入；与旧版强制偏好云的消融不可混比。",
            "恢复计数只接受新的递增观测，旧缓存不能靠并发请求重复读取制造恢复。",
            "规则执行收敛到白名单允许的显式房间操作；否定、复合、多房间和未授权动作不进行部分执行。",
            "本轮修复了模型输出日志 HTML 注入；Node DOM 测试只覆盖该渲染边界，不等于完整浏览器安全认证。",
            "AIGC 辅助实现与审阅已记录；同系列模型审阅仅为暂定评估，不是独立跨模型认证。",
        ]
    lines += [
        "", "## 整改与反证", "",
        "保留了两轮中间结果及其内容寻址源码/二进制，未覆盖不理想的数据：",
        "- 第一轮发现 8 请求门限使高并发过早降级；正式桩压力实验显式校准为 64，不改变生产默认值。",
        "- 第二轮发现条件变量队列允许新请求插队，造成长尾；改为 FIFO 有界队列并验证队列排空及入队次序。",
        "- 增加目的明确的成本边界振荡轨迹，不能将合成场景包装成真实无线抓包。",
        "- 敏感性另外加入单独的排队/RTT 门限探针，避免其他资源门限掩盖单因素影响。",
        "- 云不可用且本地过载时仍可能降级、未完成或超时，保留原始失败，没有删样本或放宽 SLA。",
        "- 没有关闭安全隔离来制造消融差异；静态模型基线只固定复杂任务去向。",
        "", "## 统计与范围", "",
        "- 分位数为 type-7；成功率为描述性 Wilson95；配对差值为 seed 簇 bootstrap 2,000 次。",
        "- 三个合成 seed 不足以证明总体可靠性；安全合同 100% 不等于实现五个九。",
        "- 回放队列是冻结外生输入，并非策略反馈下的动态排队仿真；并发效果必须看独立墙钟测试。",
        "- 画像可靠性、时限和资源预算都是设计假设，未获得真实需求方验收。",
        "- 白名单红队是结构化动作边界测试，不是完整提示注入或实体安全认证。",
        "- 未测 GPU 内存保持未知；Python CPU 时间不包含 C 子进程/GPU，不能当能耗。",
        "- ITU 官方参考页本环境未成功抓取；数值不引用其作为性能保证。",
        "", "## 事实入口", "",
        "- `../NETWORK_COMPUTE_README.md`：接口、配置、运行与口径说明。",
        "- `replay/raw_requests.jsonl`、`concurrency/raw_requests.jsonl`：逐请求事实。",
        "- `sensitivity/raw_requests.jsonl`、`safety/raw_requests.jsonl`：参数与安全证据。",
        "- `replay/switches.json`、`analysis/switch_examples.json`：可解释策略切换。",
        "- `analysis/experiment_matrix.csv`、`concurrency_metrics.csv`：矩阵与并发分位数。",
        "- `analysis/evidence_matrix.csv`：每个关键数字的 JSON 选择器。",
        "- 每个子包的 `checksums.json`、`audit.json`：完整性与复算结果。",
        "- `validation/verification.json`：工具链、命令、运行环境和完整验证状态。", "",
        "## 尚未关闭的官方提交门", "",
        "本包交付网络/算力工程与证据，不替代真实需求确认、部署成本来源、最终方案/PPT/视频/佐证同步、"
        "正式命名、永久网盘分享和报名系统回执。这些仍须单独验收，不能把本包通过写成整件作品已经完成提交。", "",
    ]
    if (run / "EXPERIMENT_AUDIT.json").is_file():
        audit = load(run / "EXPERIMENT_AUDIT.json")
        lines += [
            "## ARIS 主张审计", "",
            f"实验诚信审计结果：{audit.get('overall_verdict', audit.get('verdict', '见原始报告'))}。"
            "审阅为原生新上下文、同系列配置，语义验收仅为 provisional；未独立验证服务端模型身份。",
            "详见 `EXPERIMENT_AUDIT.md`、`RESULT_TO_CLAIM.md` 与 `aris/ASSUMPTIONS.md`。",
            "部分工况中联合策略的完成率或 p95 不优于消融；不能宣称所有负载全面领先。",
            "运行期源码冻结只覆盖 manifest 枚举文件；补存的历史测试/后端源码是运行后快照，"
            "不反向证明运行期源码身份。",
            "",
        ]
    report = "\n".join(lines)
    (run / "交付报告.md").write_text(report, encoding="utf-8")
    # Top-level checksum connects derived presentation and all frozen subpackages.
    write_json(run / "delivery_manifest.json", {
        "generated_from": str(run), "records": counts, "python_tests": tests,
        "renderer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "files": {str(path.relative_to(run)).replace("\\", "/"):
                  hashlib.sha256(path.read_bytes()).hexdigest()
                  for path in sorted(run.rglob("*")) if path.is_file()
                  and path.name != "delivery_manifest.json" and "__pycache__" not in path.parts},
    })
    print(report[:1500])


if __name__ == "__main__":
    main()
