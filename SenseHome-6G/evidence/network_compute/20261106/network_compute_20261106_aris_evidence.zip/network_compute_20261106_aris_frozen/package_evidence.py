"""Create and independently read back a new evidence archive without bytecode."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def digest(value):
    return hashlib.sha256(value).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    run = args.run.resolve()
    manifest_path = run / "delivery_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files = dict(manifest["files"])
    for name, expected in files.items():
        path = (run / name).resolve()
        if not path.is_relative_to(run) or digest(path.read_bytes()) != expected:
            raise ValueError("MANIFEST_MISMATCH:" + name)
    files["delivery_manifest.json"] = digest(manifest_path.read_bytes())
    # Exclusive creation preserves every previous archive and pilot.
    with zipfile.ZipFile(args.out, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(files):
            archive.write(run / name, run.name + "/" + name)
    with zipfile.ZipFile(args.out) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP_CRC_FAILURE")
        for name, expected in files.items():
            if digest(archive.read(run.name + "/" + name)) != expected:
                raise ValueError("ARCHIVE_CONTENT_MISMATCH:" + name)
    result = {
        "file": args.out.name, "size_bytes": args.out.stat().st_size,
        "sha256": digest(args.out.read_bytes()), "verified_archive_files": len(files),
        "zip_crc_passed": True, "manifest_hashes_read_back": True,
        "authoritative_run": run.name,
    }
    args.out.with_suffix(".sha256.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
