# ARIS 网络—算力实验交付说明

日期：2026-11-06。适用范围是网络/算力工程、实验与证据，不是正式报名已提交证明。

## 唯一主线

面向家庭智能控制的网络—算力感知 AI 网关：正常、网络退化、队列拥塞、
内存不足、模型未就绪、双模型不可用时，由唯一 C 策略选择本地规则、
本地模型或云模型；允许的命令通过白名单执行，降级与未完成必须可解释。

## 本轮补齐

- 默认 Dashboard 初始化现在启用 `ResourcePolicyClient`，不是只在台架中启用。
- 决策输入来自服务端后台健康缓存，两个模型端点分别记录 ready、queue、
  free_mem、inflight、年龄及来源。未知显存、带宽与上游排队不伪造为实测。
- 缓存年龄使用单调时钟；恢复只接受递增的新观测，旧缓存不能用并发重复读制造恢复。
- HTTP 请求上下文不能替换策略、算力或网络输入；配置由本地操作者控制。
- 默认命令规则通过既有结构化白名单，限制为显式支持的房间/动作和只读状态。
  否定、多目标、条件、全屋与未授权动作不允许局部执行后称成功。
- 策略缺失/启动失败时返回不可用，不静默切入旧的宽松演示处理器。
- 设备操作共用状态锁；HTTP 服务可并发，默认仅绑定回环。
- 日志使用文本节点显示模型内容，不允许回答文字变成执行设备 API 的 HTML。
- 界面标明 PC 模拟设备；断开 HTTP 后不再演示假的“执行成功”。

仍保留旧的仿真巡检/场景函数用于历史原型研究，它们不等于已经授权的真实家居动作。
命令入口测试不为这些旧功能提供实体安全认证。

## 最终事实源

候选目录为 `network_compute_20261106_aris_frozen/`。只有以下文件同时通过才可作为最终结果：

1. `validation/verification.json` 中 `passed=true`、
   `sources_unchanged_during_run=true`。
2. `replay`、`concurrency`、`sensitivity`、`safety`、`http_gateway` 的
   `audit.json` 均通过。
3. `交付报告.md` 由同一目录 JSON 自动生成。
4. ARIS 诚信审计与结果主张记录准确保留其 `same-family/provisional` 限制。

历史 2026-11-05 包、短烟测和 `network_compute_20261106_aris_final` 试运行保留。
后者在审阅期间源码变更，被整套冻结检查拒绝，不得因其子审计通过就称“最终验收”。
`network_compute_20261106_aris_verified` 只记录预览进程占用二进制导致的构建失败。

## 五组实验

| 组 | 测量/实现 | 注入/设计部分 | 用途 |
|---|---|---|---|
| replay | 真 C 选择、合同白名单校验、实测 IPC 另记 | 网络、排队、内存、模型/总时延成本 | 完全配对输入、分解与稳定性 |
| concurrency | 真线程、共享 FIFO 队列、IPC、白名单墙钟 | 模型为固定 sleep 桩、固定网络 | 负载与排队机制 |
| sensitivity | 真 C，12 组单因素配置 | 合成轨迹与成本 | 参数是否改变门限行为 |
| safety | PC 状态的批量原子验证 | 25 个人工构造非法输入、3 个正向合同 | 结构化白名单边界 |
| http_gateway | 默认初始化与 HTTP 入口、后台缓存、模型 HTTP、持久化事件、白名单 | 模型为固定规划桩，应用延迟/503/体积延迟注入 | 证明默认业务路径确实接通 |

画像保留 URLLC/eMBB/mMTC 与 IMT-2030 场景对应，但时延/可靠性/带宽预算是项目假设。
应用层连接失败不叫真实无线丢包；健康 HTTP 墙钟不叫 6G 空口 RTT。

## 调参和复跑

```powershell
& 'C:/Users/43068/Documents/Codex/2026-11-05/bu-s/outputs/aris-runtime/aris-python.cmd' `
  SenseHome-6G/net_offload/run_experiment_suite.py `
  --out docs/experiments/new_frozen_run
```

也可使用任意已安装的 Python 3.10+；编译器支持 gcc、clang 或 tcc。
输出目录必须是新的空目录。正式运行会重新编译 C，因此不要同时运行占用
`policy_cli.exe` 的 Windows 预览服务。

核心参数位于 `SenseHome-6G/net_offload/experiments/policy_config.json`。
业务画像位于同目录 `service_profiles.json`。
本地配置文件在网关初始化时读取，修改后需重启；事件记录有效配置及其哈希。
默认服务支持 `SENSEHOME_POLICY_CONFIG`、`SENSEHOME_SERVICE_PROFILES`、
`SENSEHOME_CLOUD_URL`、`SENSEHOME_LOCAL_URL`、`SENSEHOME_MONITOR_INTERVAL_S`、
`SENSEHOME_INFER_TIMEOUT_S`、`SENSEHOME_HEALTH_TIMEOUT_S`。
仅操作者设置 `SENSEHOME_POLICY_ARM`；对外请求不能关闭安全边界。

只重放网络文件：

```powershell
python SenseHome-6G/net_offload/experiment_replay.py `
  --trace docs/experiments/network_compute_20261106_aris_frozen/replay/trace_20261105.json `
  --out docs/experiments/new_trace_replay
```

只验证默认 HTTP 路径与压力：

```powershell
python SenseHome-6G/net_offload/experiment_http_gateway.py `
  --out docs/experiments/new_http_run
```

审计 HTTP 捕获观测：

```powershell
python SenseHome-6G/net_offload/audit_experiments.py `
  docs/experiments/network_compute_20261106_aris_frozen/http_gateway --rerun
```

`--rerun` 按 C 决策序号重放捕获观测，不要求事件完成顺序或墙钟值逐位相同。
HTTP 两臂共享配置和工作负载，不共享相同的实际健康缓存，不能声称严格配对的因果网络收益。

## 结果口径

- p50/p95/p99 为 type-7，失败也在分布中。快拒答不是成功。
- 截止时间达标必须完成合同且全程时延不超画像预算。
- 模型规划桩固定答案只证明接口与执行合同，不能证明语言理解质量。
- 多客户端闭环压力不是开放真实流量，未做协调遗漏校正。
- 默认 ready/队列采集的周期与年龄必须连同结果查看；不会把旧缓存解释成实时 GPU 遥测。
- 压力配置明确校准 inflight=64、模型桩 12/35ms，不能写成生产默认或真实 GPU 容量。
- 服务画像的 deadline/reliability 是评估预算，不是 C 已实现的资源预留保证。
- 同系列审阅有助找错，但独立性不足；机械审计只通过它实际检查的项目。
- 运行期源码门只覆盖 manifest 枚举文件。其余历史测试/后端文件补存为运行后快照，
  不能追认成当时已经冻结；此限制保留在审计中。

## 与官方赛事验收的关系

本轮能关闭“默认业务入口未接入双端点策略”的工程缺口。仍不自动关闭：
真实需求来源、具依据的部署/成本与推广方案、正式方案/PPT/视频/合并佐证同步、
匿名/许可/AIGC 最终复核、团队编号、永久网盘分享及报名系统回执。
场景设计赛道允许设计方案，无需伪造真实 6G 或家庭试点来补足这些事项。
