# Frozen ARIS Network/Compute Evidence

Date: 2026-11-06. Start with `交付报告.md`, `EXPERIMENT_AUDIT.md`,
`RESULT_TO_CLAIM.md` and `ARIS_NETWORK_COMPUTE_GUIDE.md`.

## Contents

- `replay`: 58,800 synthetic trace/modeled-service rows, actual C selection.
- `concurrency`: 6,144 direct-thread bounded-service-stub wall-clock rows.
- `sensitivity`: 9,360 exploratory OFAT rows over 12 parameter configurations.
- `safety`: 25 rejected structured-action cases and three valid controls.
- `http_gateway`: 2,940 matrix and 6,144 stress rows through the actual default
  initializer and HTTP command handler, model HTTP fixtures, whitelist and state.
- `validation`: complete-suite logs and unchanged enumerated-source verification.
- `analysis`: CSV matrices, p50/p95/p99, failure categories, evidence selectors,
  switch examples and deterministic charts generated from frozen JSON.
- `frozen_sources`: original file contents at `<sha256>/<original_basename>`.
- `source_tree`: directly runnable project-relative source copy, with all 168
  Python tests rerun successfully from that copy.
- `supplemental_source_snapshot.json`: explicitly post-run test/backend snapshots.
- `aris`: original request scope, full assumption ledger, reviewer responses,
  precheck and trace metadata. Native same-family semantic judgments are provisional.
- `ui_checks`: desktop/mobile browser screenshots and objective checks. No
  subjective visual-review claim is made because the image-view tool was unavailable.
- `delivery_manifest.json`: all delivered file digests, not a performance claim.

There are 83,416 records, not 83,416 AI inferences. Fixed model plans, service sleeps,
application-network impairment and PC device state do not constitute real AI, GPU,
physical 6G, radio protocol-stack, physical actuator or household-pilot evidence.

Each of five experiment directories has original JSONL, summary and passing
mechanical audit. HTTP events also persist per request with correlation key and
decision sequence; captured inputs replay through C in decision order.

Restore original source paths using `replay/summary.json`'s `manifest.sources`;
the basename and content digest locate each copy. Additional historical tests and
backend sources are mapped by the supplemental manifest. These supplements do not
retroactively prove that all historical test sources were frozen during execution.

To rerun from the complete project root:

```powershell
python SenseHome-6G/net_offload/run_experiment_suite.py --out docs/experiments/new_run
```

Use a new empty output directory, Python 3.10+ and gcc/clang/tcc. Effective model
budgets, stress admission limits, socket timeouts, runtime versions and source
hashes are recorded. This evidence archive is not a replacement for the complete
formally named competition code/media bundle or official submission receipt.
