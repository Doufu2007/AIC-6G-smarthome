# SenseHome 本地审阅快照（2026-11-03 v18）
本包包含当前代码、本地台架与模拟设备证据、作品方案、答辩材料、演示视频及部署记录。本地审阅包，尚未上传或提交。当前交付状态以 docs/execution/2026-11-03-delivery-checkpoint.md 为准。

20 条评测标签已由参赛者本人在本对话中逐条人工确认并冻结，正式数据集为 SenseHome-6G/net_offload/backends/eval_commands.reviewed.jsonl，冻结记录见 docs/deployment/20条动作标签冻结记录_20261103.json。docs/experiments/autodl_20261103_normalized_v2/eval.formal.json 是对已捕获真实模型响应的冻结后正式重新标注：20 条中 HTTP 成功 17 条、参考动作一致 17 条（85.0%），其中预期拒答 3/3。该报告明确记录 inference_rerun_after_freeze=false，表示冻结后没有重新调用模型，不能将重新标注描述为冻结后重新推理。

评测 CLI 默认读取 reviewed 标签；原始 eval_commands.jsonl 仅保留为草案历史，只有显式 --allow-draft-labels 才能用于预检。AutoDL 小模型运行环境、模型 revision、权重哈希、原始逐条响应及失败/保护证据均保留在 docs/experiments；大模型暂无推理结果。外部 RTOS、工具链和模型权重不在包内。SHA256SUMS.json 列出所有归档文件哈希。
