# -*- coding: utf-8 -*-
"""Capture final local checks without overwriting locked n=20 evidence."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "_work" / "final_checks_20261103"
if OUT.exists():
    raise SystemExit("Refusing to overwrite final checks; choose a new output version.")
OUT.mkdir()
env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
commands = [
    ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
     "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); & './SenseHome-6G/net_offload/run_evidence.ps1' -Out './_work/final_checks_20261103/smoke' -InferN 1 -TraceSeed 20261103 -SkipTransition"],
    [sys.executable, "_work/verify_numbers.py"],
    [sys.executable, "_work/check_draft.py"],
    [sys.executable, "-m", "unittest", "discover", "-s", "_work", "-p", "test_verify_numbers.py", "-v"],
    [sys.executable, "_work/verify_pdf.py"],
]
report = {"generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
          "scope": "current source validation plus n=1 smoke; not the original n=20 experiment provenance",
          "checks": []}
for index, command in enumerate(commands, 1):
    started = time.perf_counter()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
    output = result.stdout + "\n[stderr]\n" + result.stderr
    path = OUT / ("check_%02d.log" % index)
    path.write_text(output, encoding="utf-8")
    entry = {"index": index, "exit_code": result.returncode,
             "elapsed_s": round(time.perf_counter() - started, 3),
             "log": path.relative_to(ROOT).as_posix(),
             "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
             "python_suite_counts": [int(x) for x in re.findall(r"Ran (\d+) tests?", output)],
             "pass_lines": len(re.findall(r"^PASS  ", output, re.M))}
    report["checks"].append(entry)
    (OUT / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(entry, ensure_ascii=True), flush=True)
    if result.returncode:
        print(output[-12000:])
        raise SystemExit(result.returncode)
print("All final checks passed.")
