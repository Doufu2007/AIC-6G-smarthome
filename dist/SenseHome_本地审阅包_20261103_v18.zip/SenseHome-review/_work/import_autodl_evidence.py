"""Verify a downloaded evidence snapshot and preserve auditable public files."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    raw = args.snapshot.read_bytes()
    if hashlib.sha256(raw).hexdigest() != args.sha256:
        raise SystemExit("Snapshot hash mismatch")
    if Path(args.name).name != args.name or args.name in {".", ".."}:
        raise SystemExit("Name must be a single directory component")
    out = ROOT / "docs" / "experiments" / args.name
    out.mkdir(parents=True, exist_ok=False)
    included, excluded = {}, {}
    with zipfile.ZipFile(args.snapshot) as archive:
        if archive.testzip() is not None:
            raise SystemExit("Snapshot CRC failure")
        for item in archive.infolist():
            if item.is_dir():
                continue
            parts = Path(item.filename).parts
            if Path(item.filename).is_absolute() or ".." in parts:
                raise SystemExit("Invalid archive path")
            data = archive.read(item)
            entry = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            if "quarantine_untrusted_reviewed" in parts:
                excluded[item.filename] = {**entry, "reason": "Invalid machine-created reviewed copy; never used as formal labels"}
                continue
            destination = out.joinpath(*parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            included[item.filename] = entry
    receipt = {
        "snapshot": args.snapshot.name,
        "snapshot_bytes": len(raw),
        "snapshot_sha256": args.sha256,
        "scope": "Remote execution evidence; draft labels remain draft; no physical device or 6G air interface",
        "excluded_untrusted_labels": excluded,
        "files": included,
    }
    (out / "snapshot-source.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"imported_files": len(included), "quarantined_files_omitted": len(excluded), "out": out.relative_to(ROOT).as_posix()}, ensure_ascii=True))


if __name__ == "__main__":
    main()
