"""Read final PDF pagination without a fixed number of cover/TOC pages."""
from __future__ import annotations

import re
from pathlib import Path


def norm(text):
    return re.sub(r"\s+", "", text)


def intro_anchor(md_path):
    text = Path(md_path).read_text(encoding="utf-8")
    match = re.search(r"^## 作品简介[^\n]*\n(.*?)\n---", text, re.M | re.S)
    if not match:
        raise ValueError("cannot locate introduction")
    for line in match.group(1).splitlines():
        if line.strip():
            return norm(line)[:22]
    raise ValueError("empty introduction")


def body_start(document, md_path):
    anchor = intro_anchor(md_path)
    for i, page in enumerate(document):
        if anchor in norm(page.get_text()):
            return i
    raise ValueError("cannot locate introduction text in PDF")


def printed_page(page):
    candidates = []
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):
            text = "".join(span["text"] for span in line.get("spans", [])).strip()
            x0, y0, x1, y1 = line["bbox"]
            center_x = (x0 + x1) / 2
            if (y0 > page.rect.height * 0.91 and page.rect.width * 0.4 < center_x < page.rect.width * 0.6
                    and re.fullmatch(r"\d+", text)):
                candidates.append(int(text))
    if len(candidates) != 1:
        raise ValueError(f"page {page.number + 1}: expected one footer number, got {candidates}")
    return candidates[0]


def title_pages(document, titles, start):
    pages = [norm(p.get_text()) for p in document]
    out = {}
    cursor = start
    for title in titles:
        key = norm(title)
        for i in range(cursor, len(document)):
            if key in pages[i]:
                out[title] = printed_page(document[i])
                cursor = i
                break
        else:
            raise ValueError(f"heading not found: {title}")
    return out
