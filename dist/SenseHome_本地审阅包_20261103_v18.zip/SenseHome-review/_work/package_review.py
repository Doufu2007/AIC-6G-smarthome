# -*- coding: utf-8 -*-
"""Build a local review snapshot; never uploads or pretends to be final submission."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
PACKAGE = DIST / "SenseHome_本地审阅包_20261103.zip"
HASHES = DIST / "SenseHome_本地审阅包_20261103.sha256.json"


def select_files() -> list[Path]:
    selected: set[Path] = set()
    net = ROOT / "SenseHome-6G" / "net_offload"
    for path in net.rglob("*"):
        relative = path.relative_to(net)
        if not path.is_file() or any(part in {"__pycache__", "_work"} for part in relative.parts):
            continue
        if len(relative.parts) > 1 and relative.parts[0] == "results" and relative.parts[1] != "runs":
            if relative.name not in {"results.json", "results.md"}:
                continue
        if path.suffix in {".py", ".c", ".h", ".ps1", ".md", ".json", ".jsonl", ".example"}:
            selected.add(path)
    home = ROOT / "openvela_smart_home"
    for directory in ("dashboard", "tools", "skills", "security", "patches"):
        for path in (home / directory).rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix not in {".pyc", ".exe", ".o"}:
                selected.add(path)
    for name in ("Makefile", "LICENSE", "NOTICE", "auto_build_vela.sh", "switch_llm.sh", "smoke_test.sh", "test_runner.sh"):
        selected.add(home / name)
    selected.add(home / "docs" / "THIRD_PARTY.md")
    project = ROOT / "SenseHome-6G"
    for name in ("作品方案_场景设计_v1.md", "作品方案_场景设计_v1.docx", "作品方案_场景设计_v1.pdf"):
        selected.add(project / name)
    for directory in ("compliance", "evidence/current"):
        for path in (project / directory).rglob("*"):
            if path.is_file():
                selected.add(path)
    for name in ("submission_architecture.png", "submission_workflow.png"):
        selected.add(project / "figures" / name)
    for name in ("verify_numbers.py", "test_verify_numbers.py", "check_draft.py", "capture_dashboard_evidence.py", "correct_probe_overheads.py"):
        selected.add(ROOT / "_work" / name)
    for name in ("results.json", "results.corrected.json", "provenance.json"):
        selected.add(ROOT / "_work" / "evidence_final" / name)
    for name in ("演示视频_分镜脚本_v1.md", "答辩PPT_页面大纲.md", "提交材料差距审计.md"):
        selected.add(ROOT / name)
    for directory in ("docs/reviews", "docs/execution"):
        selected.update(path for path in (ROOT / directory).rglob("*.md"))
    missing = [str(path.relative_to(ROOT)) for path in selected if not path.is_file()]
    if missing:
        raise SystemExit("Missing review artifacts: " + ", ".join(sorted(missing)))
    return sorted(selected, key=lambda p: p.relative_to(ROOT).as_posix())


def main() -> None:
    DIST.mkdir(exist_ok=True)
    if PACKAGE.exists() or HASHES.exists():
        raise SystemExit("Refusing to overwrite an existing review snapshot; choose a new version.")
    files = select_files()
    manifest = {}
    for path in files:
        raw = path.read_bytes()
        manifest[path.relative_to(ROOT).as_posix()] = {
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        }
    note = """# SenseHome 本地审阅快照（2026-11-03）

这是本地可审阅代码与证据快照，尚未上传或提交。压缩包不是赛事最终材料包；
队伍编号、永久网盘链接、最终3—5分钟MP4、答辩PDF和真实模型补证尚未齐备。

先读：SenseHome-6G/net_offload/README.md 与提交材料差距审计.md。
Windows PowerShell 从本包根目录运行：

    ./SenseHome-6G/net_offload/build.ps1
    python _work/verify_numbers.py
    python _work/check_draft.py
    python openvela_smart_home/dashboard/bridge_server.py --patrol-interval 0

打开 Dashboard 后仍是 PC 模拟设备；未配置模型URL时复杂任务会显式回退。
真实模型配置见 SenseHome-6G/net_offload/AutoDL_真实模型验证.md。

当前480条网络台架请求的模型时延/语义是STUB合同，另有160条Dashboard规则
请求确认了PC JSON状态。原始结果与只修正探测聚合的派生结果同时保存，
provenance.json说明各自来源；最新构建manifest是构建时的源码快照，
不能倒推实验发生时所有源码完全相同。

外部RTOS、工具链和模型权重不包含在包内；依赖与许可按compliance清单复核。
SHA256SUMS.json列出全部原始文件的字节数和哈希。请勿把测试fake key当作凭证。
"""
    with zipfile.ZipFile(PACKAGE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, "SenseHome-review/" + path.relative_to(ROOT).as_posix())
        archive.writestr("SenseHome-review/REVIEW_README.md", note.encode("utf-8"))
        archive.writestr("SenseHome-review/SHA256SUMS.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    digest = hashlib.sha256(PACKAGE.read_bytes()).hexdigest()
    HASHES.write_text(json.dumps({"package": PACKAGE.name, "bytes": PACKAGE.stat().st_size,
                                 "sha256": digest, "files": manifest}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"package": str(PACKAGE), "n_files": len(files) + 2,
                      "bytes": PACKAGE.stat().st_size, "sha256": digest}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
