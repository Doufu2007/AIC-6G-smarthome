# -*- coding: utf-8 -*-
"""对作品方案草稿做三项机检：
① 作品简介字数是否落在 300-500；
② 作品名称是否 <=20 字；
③ 全文是否残留脱敏禁用串（单位名/指导教师/手机号等）。
默认从脚本位置定位项目，避免依赖当前目录。"""
import os
import re
import json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(ROOT, "SenseHome-6G")
DRAFT = os.path.join(BASE, "作品方案_场景设计_v1.md")

text = open(DRAFT, encoding="utf-8").read()

# --- ① 作品简介字数 ---
def section_chars(start_pat, end_pat):
    m = re.search(start_pat + r"(.*?)" + end_pat, text, re.S)
    if not m:
        return None
    paras = [p.strip() for p in m.group(1).split("\n") if p.strip()]
    return len(re.sub(r"\s", "", "".join(paras)))


length_errors = []
for label, start, end in [
    ("作品简介", r"## 作品简介[^\n]*\n", r"\n---"),
    ("场景摘要", r"## （四）场景摘要\n", r"\n---"),
]:
    n = section_chars(start, end)
    if n is None:
        print("%s：** 未找到该节 **" % label)
        length_errors.append("未找到%s" % label)
    else:
        flag = "OK" if 300 <= n <= 500 else "** 越界 **"
        if not 300 <= n <= 500:
            length_errors.append("%s 字符数 %d 不在 300-500" % (label, n))
        print("%s：%d 字符（要求 300-500）%s" % (label, n, flag))

# --- ② 作品名称长度 ---
title_match = re.search(r"\|\s*作品名称\s*\|\s*\*\*(.*?)\*\*", text)
name = title_match.group(1).strip() if title_match else ""
name_ok = bool(name) and len(name) <= 20
print("作品名称：%d 字符 -> %s%s" % (len(name), name, "" if name_ok else " ** 超长 **"))
if not name_ok:
    length_errors.append("作品名称缺失或长度 %d 不在 1-20" % len(name))

# --- ③ 脱敏禁用串扫描 ---
# Personal identities stay in a local profile excluded from the public package.
# A copied checker can supply its own profile or use these generic guards.
BANNED = ["指导教师", "指导老师"]
private_profile = os.path.join(os.path.dirname(os.path.abspath(__file__)), "check_draft.private.json")
if os.path.isfile(private_profile):
    BANNED.extend(json.load(open(private_profile, encoding="utf-8")))
BANNED = list(dict.fromkeys(BANNED))
hits = []
for b in BANNED:
    for i, line in enumerate(text.split("\n"), 1):
        if b in line:
            hits.append((b, i, line.strip()[:70]))
for i, line in enumerate(text.split("\n"), 1):
    if re.search(r"(?<!\d)1[3-9]\d{9}(?!\d)", line):
        hits.append(("手机号样式", i, "[内容已省略]"))
def safe(s):
    return s.encode("ascii", "replace").decode("ascii")


if hits:
    print("\n[FAIL] 命中禁用串：")
    for b, i, ln in hits:
        print(safe("  L%-4d [%s] %s" % (i, b, ln)))
else:
    print("\n[OK] 未命中任何脱敏禁用串")

# --- ④ 字体可用性：正文里只许用中易宋体能渲染的符号 ---------------------
# 为什么在 md 侧查而不是只靠 verify_pdf.py：转 PDF 要跑两遍 LibreOffice（约 2 分钟），
# 而字库缺字时 LibreOffice 是**静默**换字体的 —— 只有拿到 PDF 才能发现，太晚。
# 实测教训：2026-10-16 我在附录里写了一个 ⚠️（U+26A0 U+FE0F），
# PDF 里落成 NotoSansSC-Thin 的 **Type3 未嵌入**字体，在评审机上可能显示为方框。
# 白名单＝已经跑通过的符号集；新符号一律先在这里挡住。
OK_SYMBOLS = set(
    "–—‘’“”…×≤≥→≡≈µ℃※①②③④⑤⑥⑦⑧⑨⑩◎★☆□■√△○●"
)
bad_chars = {}
for i, line in enumerate(text.split("\n"), 1):
    for ch in line:
        o = ord(ch)
        if o < 0x2000:
            continue                       # ASCII 与常用拉丁扩展，字库肯定有
        if (0x3000 <= o <= 0x303F or 0x4E00 <= o <= 0x9FFF
                or 0xFF00 <= o <= 0xFFEF or 0x2000 <= o <= 0x206F):
            continue                       # CJK 标点 / 汉字 / 全角 / 通用标点
        if ch in OK_SYMBOLS:
            continue
        bad_chars.setdefault(ch, []).append(i)

if bad_chars:
    print("\n[FAIL] 有字库未验证的符号（可能被 LibreOffice 静默换字体）：")
    for ch, lines in bad_chars.items():
        print(safe("  U+%04X %s  出现在 L%s" % (ord(ch), ch, lines[:8])))
else:
    print("[OK] 无未验证符号")

# --- ⑤ 同一事实两处各自维护：奖项与赛道名必须同现同源 -------------------
# 教训：同一事实若在两个地方各自维护，迟早会静默分叉。
# 本稿的赛道名原先在 3 处出现、且有 2 种写法（第二章（二）3.1、附录第 8 项、
# 团队表）——团队表那处已改为"见附录第 8 项"，只留两个承重位置。
# 本门同时要求：承重位置恰好 2 个，且每处都必须同时写出奖项。
TRACK = "开源任务挑战赛道-基于 openvela 智能体的智能家居控制系统"
AWARD = "三等奖"
carriers = [l for l in text.split("\n") if TRACK in l]
drift = (len(carriers) != 2) or not all(AWARD in l for l in carriers)
if drift:
    print("\n[FAIL] 赛道名与奖项的事实源不唯一或不同现：")
    print(safe("  赛道名「%s」出现在 %d 行（期望 2 行：第二章（二）3.1 与附录第 8 项）"
               % (TRACK, len(carriers))))
    for l in carriers:
        print(safe("    %s  [%s]" % ("含奖项" if AWARD in l else "** 缺奖项 **", l.strip()[:90])))
else:
    print("[OK] 赛道名与奖项：2 处承重位置，逐处同现")

# --- 附：字数总览 ---
print("\n全文字符数（含标点与空白）：%d" % len(text))

if length_errors:
    print("\n[FAIL] 字段长度校验：")
    for error in length_errors:
        print("  " + error)

if hits or bad_chars or drift or length_errors:
    raise SystemExit(1)
