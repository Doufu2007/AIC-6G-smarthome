"""针对数字门的证据篡改回归测试，不修改结果事实源。"""
import copy
import importlib.util
from pathlib import Path
import unittest


SCRIPT = Path(__file__).with_name("verify_numbers.py")
SPEC = importlib.util.spec_from_file_location("verify_numbers", SCRIPT)
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class VerifyRecoveryTests(unittest.TestCase):
    def evidence(self):
        phases = ("P1-normal", "P2-degraded", "P3-wan-down", "P4-all-down")
        return {
            "probe_overheads": [
                {"phase": phase, "median_probe_ms": 1.0, "n_probes": 1}
                for phase in phases
            ],
            "raw_runs": [
                {"phase": phase, "arm": "adaptive", "rows": [{"probe_ms": 1.0, "wan_probe_ok": True}]}
                for phase in phases
            ],
            "transition_trace": [
                {"step": "30", "backend_complex": "cloud-model"},
                {"step": "600", "backend_complex": "local-model"},
                {"step": "BLACKOUT", "backend_complex": "local-model"},
                {"step": "30", "backend_complex": "local-model"},
                {"step": "30", "backend_complex": "cloud-model"},
            ],
            "recovery": {
                "recovered": True, "probes_to_leave": 1,
                "probes_after_blackout_to_cloud": 2,
                "probes_to_recover": 3, "total_probes": 5,
            },
        }

    def test_accepts_recovery_recomputed_from_trace(self):
        errors = []
        VERIFY.check_derived(self.evidence(), errors)
        self.assertEqual(errors, [])

    def test_rejects_each_tampered_recovery_count(self):
        for field in ("probes_to_leave", "probes_after_blackout_to_cloud", "probes_to_recover", "total_probes"):
            with self.subTest(field=field):
                data = copy.deepcopy(self.evidence())
                data["recovery"][field] += 1
                errors = []
                VERIFY.check_derived(data, errors)
                self.assertTrue(any("recovery" in error for error in errors), errors)

    def test_rejects_tampered_recovered_flag(self):
        data = self.evidence()
        data["recovery"]["recovered"] = False
        errors = []
        VERIFY.check_derived(data, errors)
        self.assertTrue(any("recovery" in error for error in errors), errors)


if __name__ == "__main__":
    unittest.main()
