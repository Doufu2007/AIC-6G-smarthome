"""Capture actual C policy -> Dashboard rule -> JSON state transactions.

This measures the PC device simulator, not target MCU or physical actuators.
"""
import json
import math
from pathlib import Path
import statistics
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'openvela_smart_home' / 'dashboard'))
import bridge_server as bridge
from offload_gateway import LinkSnapshot, OffloadGateway, RuleBackend, SubprocessPolicyClient, append_jsonl

OUT = ROOT / 'SenseHome-6G' / 'evidence' / 'current' / 'dashboard'
OUT.mkdir(parents=True, exist_ok=True)
event_file = OUT / 'events.jsonl'
if event_file.exists():
    raise SystemExit('Refusing to overwrite existing evidence; choose a fresh output directory.')
cli = str(Path(bridge.NET_OFFLOAD_DIR) / ('policy_cli.exe' if sys.platform == 'win32' else 'policy_cli'))
rows = []
original_gateway, original_state, original_monitor = bridge.gateway, bridge.STATE_FILE, bridge.backend_monitor
try:
    bridge.backend_monitor = None
    with tempfile.TemporaryDirectory() as temporary:
        bridge.STATE_FILE = str(Path(temporary) / 'state.json')
        bridge.save_state(bridge.default_state())
        for phase, link in [
            ('P1-normal', LinkSnapshot(wan_ok=True, wan_rtt_ms=30, lan_ok=True, lan_rtt_ms=3)),
            ('P2-degraded', LinkSnapshot(wan_ok=True, wan_rtt_ms=400, lan_ok=True, lan_rtt_ms=3)),
            ('P3-wan-down', LinkSnapshot(wan_ok=False, lan_ok=True, lan_rtt_ms=3)),
            ('P4-all-down', LinkSnapshot(wan_ok=False, lan_ok=False)),
        ]:
            policy = SubprocessPolicyClient(cli)
            try:
                bridge.gateway = OffloadGateway(
                    policy, {'local-rules': RuleBackend(bridge._gateway_local_handler)},
                    link_snapshot=link, event_sink=append_jsonl(str(event_file)),
                    action_executor=bridge._gateway_action_executor,
                )
                for task in ('simple', 'safety'):
                    for index in range(20):
                        command = ('打开客厅的灯' if index % 2 == 0 else '关闭客厅的灯') if task == 'simple' else '查询安防状态'
                        start = time.perf_counter()
                        result = bridge.process_command(command)
                        wall_ms = (time.perf_counter() - start) * 1000
                        state = bridge.load_state()
                        confirmed = (state['lights']['客厅']['is_on'] == (index % 2 == 0)) if task == 'simple' else result['semantic_complete']
                        if not confirmed or result['backend'] != 'local-rules' or result['latency']['probe_ms'] != 0:
                            raise RuntimeError('Dashboard control contract failed')
                        rows.append({'phase': phase, 'task': task, 'index': index,
                                     'event_id': result['event_id'], 'wall_ms': wall_ms,
                                     'state_confirmed': bool(confirmed), 'source': 'dashboard-device-simulator'})
            finally:
                policy.close()
finally:
    bridge.gateway, bridge.STATE_FILE, bridge.backend_monitor = original_gateway, original_state, original_monitor

summaries = []
for phase in dict.fromkeys(row['phase'] for row in rows):
    for task in ('simple', 'safety'):
        group = [row for row in rows if row['phase'] == phase and row['task'] == task]
        samples = sorted(row['wall_ms'] for row in group)
        summaries.append({'phase': phase, 'task': task, 'n': len(group),
                          'p50_wall_ms': round(statistics.median(samples), 3),
                          'p95_wall_ms': round(samples[math.ceil(.95 * len(samples)) - 1], 3),
                          'n_state_confirmed': sum(row['state_confirmed'] for row in group)})
report = {'meta': {'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                   'source': 'dashboard-device-simulator',
                   'scope': 'C policy + real Python Dashboard rules + simulated JSON device state; no physical actuator'},
          'summaries': summaries, 'rows': rows}
(OUT / 'dashboard_results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summaries, ensure_ascii=True, indent=2))
