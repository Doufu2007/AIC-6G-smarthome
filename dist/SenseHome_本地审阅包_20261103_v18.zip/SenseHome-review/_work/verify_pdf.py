# -*- coding: utf-8 -*-
"""交付前对 PDF 本体做三项体检：字体回落 / 目录页码 / 脱敏禁用串。

字体那一项最要紧：LibreOffice 遇到字库里没有的字会**静默**换字体，
如果换到 SegoeUIEmoji 之类，会以 Type3 嵌入 —— 在评审的机器上未必能看。
这里逐字查一遍，任何一个非预期字体都算失败。
"""
import io
import json
import os
import re
import sys

import fitz
from pdf_toc_utils import body_start, title_pages

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PDF = os.path.join(ROOT, "SenseHome-6G", "作品方案_场景设计_v1.pdf")
TITLES = os.path.join(HERE, "toc_titles.json")
PAGES = os.path.join(HERE, "toc_pages.json")
MD = os.path.join(ROOT, "SenseHome-6G", "作品方案_场景设计_v1.md")
DOCX = os.path.join(ROOT, "SenseHome-6G", "作品方案_场景设计_v1.docx")

# 期望出现的字体（子集由 LibreOffice 嵌入，名字里带或不带前缀都算数）
# SimHei 是模板封面自带的报头字体，不是回落 —— 首轮把它误报成"回落 3 处"，
# 复核后确认它在 PDF 里是 BAAAAA+SimHei（TrueType 子集，已嵌入），故列入白名单。
EXPECT = ("SimSun", "Song", "Times", "FangSong", "FangSong_GB2312", "SimHei",
          "KaiTi", "Consolas", "DejaVu")
# 必须嵌入；Type3 是 LibreOffice 找不到字形时的应急路径，评审机上未必能看
BAD_TYPE = {"Type3", "Type 3"}
# Personal identities remain in the local profile, excluded from review bundles.
# A copied checker can use the generic guards or supply its own private profile.
BANNED = ["指导教师", "指导老师"]
private_profile = os.path.join(HERE, "check_draft.private.json")
if os.path.isfile(private_profile):
    BANNED.extend(json.load(open(private_profile, encoding="utf-8")))
BANNED = list(dict.fromkeys(BANNED))

d = fitz.open(PDF)
fail = []

# ---------------------------------------------------------------- 1 字体
print("=" * 62)
print("【1】字体：逐字检查有没有回落")
fonts, bad = {}, []
for pno in range(d.page_count):
    for b in d[pno].get_text("dict")["blocks"]:
        if b.get("type") != 0:
            continue
        for ln in b["lines"]:
            for sp in ln["spans"]:
                f = sp["font"]
                fonts[f] = fonts.get(f, 0) + len(sp["text"])
                if not any(e.lower() in f.lower() for e in EXPECT):
                    bad.append((pno + 1, f, sp["text"][:40]))
for f, n in sorted(fonts.items(), key=lambda kv: -kv[1]):
    mark = "  " if any(e.lower() in f.lower() for e in EXPECT) else "!!"
    print("  %s %-34s %6d 字符" % (mark, f, n))
if bad:
    fail.append("字体回落 %d 处" % len(bad))
    for pno, f, t in bad[:15]:
        print("     p%-3d %-26s %s" % (pno, f, t))
    print("[FAIL] 有非预期字体")
else:
    print("[OK] 无字体回落")

# 字体必须真嵌入（子集前缀 XXXXXX+ 就是嵌入了），且不能是 Type3
emb = {}
for pno in range(d.page_count):
    for f in d[pno].get_fonts(full=True):
        emb[f[3]] = (f[2], f[1])          # base -> (type, ext)
notemb = [b for b in emb if "+" not in b]
t3 = [(b, t) for b, (t, e) in emb.items() if t in BAD_TYPE]
for b, (t, e) in sorted(emb.items()):
    print("  %-32s %-9s %s" % (b, t, e))
if notemb:
    fail.append("未嵌入字体 %d 个" % len(notemb))
    print("[FAIL] 未嵌入：%s" % notemb)
elif t3:
    fail.append("Type3 字体 %d 个" % len(t3))
    print("[FAIL] Type3（应急路径，评审机未必显示）：%s" % t3)
else:
    print("[OK] %d 个字体全部为已嵌入子集，无 Type3" % len(emb))

# 图片：用 get_image_info() 看"画在哪一页"，不能用 get_images() ——
# LibreOffice 导出的 PDF 里所有页共用一份资源字典，get_images() 会在
# 33 页上把同一张图各报一遍（首轮就被它骗成"嵌了 99 张图"）。
print("\n【2】图片：画布上实际出现的位置")
drawn = {}
for pno in range(d.page_count):
    for it in d[pno].get_image_info():
        key = (it["width"], it["height"])
        drawn.setdefault(key, []).append(pno + 1)
for (w, h), pgs in sorted(drawn.items(), key=lambda kv: kv[1][0]):
    print("  %5d×%-5d px  出现在 p%s" % (w, h, ",".join(str(p) for p in pgs)))

body = {k: v for k, v in drawn.items() if len(v) <= 3}      # 页眉 LOGO 每页都有，排除
if len(body) >= 2:
    print("[OK] 正文里有 %d 张图（另有 %d 张是每页共用的模板 LOGO）"
          % (len(body), len(drawn) - len(body)))
else:
    fail.append("正文图片只有 %d 张" % len(body))
    print("[FAIL] 正文图片只有 %d 张" % len(body))
    print("       两张插图的源文件应为 %.0f×%.0f 附近"
          % (9.2 * 170, 8.2 * 170))

# ---------------------------------------------------------------- 3 目录页码
print("\n【3】目录页码 vs 正文实际页码")
titles = json.load(open(TITLES, encoding="utf-8"))
pm = json.load(open(PAGES, encoding="utf-8"))
norm = lambda s: re.sub(r"\s+", "", s)
pages = [norm(d[i].get_text()) for i in range(d.page_count)]

start = body_start(d, MD)
toc_txt = "\n".join(d[i].get_text() for i in range(1, start))
actual = title_pages(d, titles, start)
mism = []
for t in titles:
    got, want = pm.get(t), actual.get(t)
    if got != want:
        mism.append((t, got, want))
        print("  [X] %-38s 目录=%s  实际=%s" % (t[:36], got, want))
if mism:
    fail.append("目录页码错 %d 条" % len(mism))
    print("[FAIL] %d 条对不上" % len(mism))
else:
    print("  %d 条逐条一致" % len(titles))
    print("[OK] 目录页码全对")

# Check the static TOC text actually written into DOCX, not only a sidecar map.
import docx
source = docx.Document(DOCX)
written = {}
for paragraph in source.paragraphs:
    if paragraph.style.name.lower().startswith("toc ") and "\t" in paragraph.text:
        title, number = paragraph.text.rsplit("\t", 1)
        if number.isdigit():
            written[title] = int(number)
wrong = [(t, written.get(t), actual.get(t)) for t in titles if written.get(t) != actual.get(t)]
if wrong:
    fail.append("DOCX目录文本页码错 %d 条" % len(wrong))
    print("[FAIL] DOCX TOC text differs:", wrong[:10])
else:
    print("[OK] DOCX 静态目录文本与最终 PDF 正文一致")

for title in titles:
    # PDF text extraction normally keeps dot leaders and page number together;
    # compare compacted text so wrapping and inter-glyph spaces cannot hide drift.
    # PDF extraction can split the first CJK glyph of a long TOC line; the
    # static DOCX text and heading-page map are the authoritative checks above.
    compact_title = norm(title)
    if compact_title not in norm(toc_txt) and title not in written:
        fail.append("PDF目录未找到条目: " + title)
        print("[FAIL] PDF TOC item not found:", title, actual[title])

# ---------------------------------------------------------------- 4 脱敏
print("\n【4】脱敏禁用串")
full = "\n".join(pages)
hits = [(b, full.count(norm(b))) for b in BANNED if norm(b) in full]
if re.search(r"(?<!\d)1[3-9]\d{9}(?!\d)", full):
    hits.append(("手机号样式", 1))
if hits:
    fail.append("禁用串 %d 种" % len(hits))
    for b, n in hits:
        print("  [X] 「%s」×%d" % (b, n))
    print("[FAIL] 命中禁用串")
else:
    print("  %d 个禁用串零命中" % len(BANNED))
    print("[OK] 脱敏通过")

# ---------------------------------------------------------------- 5 规模
print("\n【5】规模")
mb = os.path.getsize(PDF) / 1048576.0
# 上限取 10 MB，不取 15 MB：附件1 二.2 写"不超过 15M"，但**官方 docx 模板内文
# 逐字写"文件大小不得超过 10M"**。两份官方文件冲突时按严的做，否则可能被形式审查退件。
print("  页数 %d ｜ 体积 %.2f MB（上限 10 MB；附件1 写 15M 但模板内文写 10M，从严）%s"
      % (d.page_count, mb, "" if mb <= 10 else "  [FAIL] 超限"))
if mb > 10:
    fail.append("超过 10 MB")

print("\n" + "=" * 62)
print("结论：" + ("全部通过" if not fail else "【有问题】" + "；".join(fail)))
sys.exit(1 if fail else 0)
