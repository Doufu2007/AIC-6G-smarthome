"""Correct probe-only summaries from immutable per-request evidence rows."""
from __future__ import annotations

import copy
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NET = ROOT / "SenseHome-6G" / "net_offload"
sys.path.insert(0, str(NET))

from evidence import validate_results_schema
from offload_bench import probe_overhead


def main() -> None:
    source = ROOT / "_work" / "evidence_final" / "results.json"
    corrected = source.with_name("results.corrected.json")
    payload = source.read_bytes()
    source_hash = hashlib.sha256(payload).hexdigest()
    original = json.loads(payload.decode("utf-8"))
    data = copy.deepcopy(original)
    data["probe_overheads"] = [
        dict(probe_overhead(run), phase=run["phase"])
        for run in data["raw_runs"] if run["arm"] == "adaptive"
    ]
    data["meta"]["derivation"] = {
        "source": "_work/evidence_final/results.json",
        "source_sha256": source_hash,
        "method": "recompute probe_overheads from unchanged raw_runs; only rows with wan_probe_ok != null are probes",
        "script": "_work/correct_probe_overheads.py",
        "benchmark_source_sha256": hashlib.sha256((NET / "offload_bench.py").read_bytes()).hexdigest(),
    }
    data["meta"]["correction"] = (
        "Previous median_probe_ms included 40 zero values from local fast paths that did not probe; "
        "recomputed over the 20 actual probe requests in each adaptive phase. "
        "Raw rows, latency summaries, paired traces and the original results.json remain unchanged."
    )
    assert data["raw_runs"] == original["raw_runs"]
    errors = validate_results_schema(data)
    if errors:
        raise SystemExit("\n".join(errors))
    text = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    corrected.write_text(text, encoding="utf-8")
    (NET / "results" / "results.json").write_text(text, encoding="utf-8")
    assert hashlib.sha256(source.read_bytes()).hexdigest() == source_hash
    for row in data["probe_overheads"]:
        print(row["phase"], "n_probes=", row["n_probes"], "median_probe_ms=", row["median_probe_ms"])
    print("schema valid; original source hash preserved:", source_hash)


if __name__ == "__main__":
    main()
