# 链路自适应推理卸载 — 测量结果

生成时间：2026-11-03 04:21:21

> **读数纪律**：本表 `stub_compute_ms` 一栏是**注入的桩参数**，不是测量值。`e2e_ms` 按用户口径计为 `probe_ms + policy_ms + backend_ms`；后端段原始耗时保存在 `backend_e2e_ms`。详见 §口径。

## 表 A · 各链路档位下的决策与完成率

**两栏完成率必须分开读**：
- *接口成功率* = 请求得到了响应（哪怕响应内容是「无法理解」）。
- *语义合同完成率* = 当前合成标签满足后端合同；不代表真实命令准确率。

断网时接口成功率可以是 100%，而语义完成率掉到 0 —— 那正是「能力降级」，不是「成功」。只报前者就是误导。

| 阶段 | 臂 | WAN 条件 | 任务 | 决策 | 该档能力 | 接口成功率 | 语义完成率 | 探测中位 | 策略中位 | 后端中位 | 用户总时延中位 (ms) | 网络中位 | 桩 (ms) | n |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P1 链路正常 | adaptive | RTT 30/抖动 5/失败率 0% | simple | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.11 | 0.02 | 0.13 | 0.0 | 0.0 | 1 |
| P1 链路正常 | adaptive | RTT 30/抖动 5/失败率 0% | complex | cloud-model | 合成标签完成 | 100.0% | 100.0% | 65.7 | 0.12 | 352.3 | 418.1 | 51.6 | 300.0 | 1 |
| P1 链路正常 | adaptive | RTT 30/抖动 5/失败率 0% | safety | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.13 | 0.03 | 0.16 | 0.0 | 0.0 | 1 |
| P1 链路正常 | static-cloud | RTT 30/抖动 5/失败率 0% | simple | cloud-model | 合成标签完成 | 100.0% | 100.0% | 0.0 | 0.0 | 337.3 | 337.3 | 36.9 | 300.0 | 1 |
| P1 链路正常 | static-cloud | RTT 30/抖动 5/失败率 0% | complex | cloud-model | 合成标签完成 | 100.0% | 100.0% | 0.0 | 0.0 | 338.8 | 338.8 | 38.3 | 300.0 | 1 |
| P1 链路正常 | static-cloud | RTT 30/抖动 5/失败率 0% | safety | cloud-model | 合成标签完成 | 100.0% | 100.0% | 0.0 | 0.0 | 342.9 | 342.9 | 42.5 | 300.0 | 1 |
| P2 WAN 劣化 | adaptive | RTT 400/抖动 80/失败率 10% | simple | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.06 | 0.01 | 0.07 | 0.0 | 0.0 | 1 |
| P2 WAN 劣化 | adaptive | RTT 400/抖动 80/失败率 10% | complex | local-model | 合成标签完成 | 100.0% | 100.0% | 464.7 | 0.07 | 176.4 | 641.2 | 26.2 | 150.0 | 1 |
| P2 WAN 劣化 | adaptive | RTT 400/抖动 80/失败率 10% | safety | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.19 | 0.02 | 0.21 | 0.0 | 0.0 | 1 |
| P2 WAN 劣化 | static-cloud | RTT 400/抖动 80/失败率 10% | simple | cloud-model | 合成标签完成 | 100.0% | 100.0% | 0.0 | 0.0 | 713.6 | 713.6 | 413.1 | 300.0 | 1 |
| P2 WAN 劣化 | static-cloud | RTT 400/抖动 80/失败率 10% | complex | cloud-model | 合成标签完成 | 100.0% | 100.0% | 0.0 | 0.0 | 773.4 | 773.4 | 473.0 | 300.0 | 1 |
| P2 WAN 劣化 | static-cloud | RTT 400/抖动 80/失败率 10% | safety | cloud-model | 合成标签完成 | 100.0% | 100.0% | 0.0 | 0.0 | 750.2 | 750.2 | 449.9 | 300.0 | 1 |
| P3 WAN 断链（LAN 尚存） | adaptive | 断链 | simple | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.1 | 0.02 | 0.12 | 0.0 | 0.0 | 1 |
| P3 WAN 断链（LAN 尚存） | adaptive | 断链 | complex | local-model | 合成标签完成 | 100.0% | 100.0% | 46.8 | 0.1 | 180.0 | 226.9 | 29.9 | 150.0 | 1 |
| P3 WAN 断链（LAN 尚存） | adaptive | 断链 | safety | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.15 | 0.02 | 0.17 | 0.0 | 0.0 | 1 |
| P3 WAN 断链（LAN 尚存） | static-cloud | 断链 | simple | cloud-model | 合成标签完成 | 0.0% | 0.0% | 0.0 | 0.0 | 12.7 | 12.7 | None | None | 1 |
| P3 WAN 断链（LAN 尚存） | static-cloud | 断链 | complex | cloud-model | 合成标签完成 | 0.0% | 0.0% | 0.0 | 0.0 | 1.13 | 1.13 | None | None | 1 |
| P3 WAN 断链（LAN 尚存） | static-cloud | 断链 | safety | cloud-model | 合成标签完成 | 0.0% | 0.0% | 0.0 | 0.0 | 0.86 | 0.86 | None | None | 1 |
| P4 全网断链 | adaptive | 断链 | simple | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.07 | 0.01 | 0.08 | 0.0 | 0.0 | 1 |
| P4 全网断链 | adaptive | 断链 | complex | local-rules | simple/safety 完成 | 100.0% | 0.0% | 22.6 | 0.05 | 0.01 | 22.7 | 0.0 | 0.0 | 1 |
| P4 全网断链 | adaptive | 断链 | safety | local-rules | simple/safety 完成 | 100.0% | 100.0% | 0.0 | 0.05 | 0.01 | 0.06 | 0.0 | 0.0 | 1 |
| P4 全网断链 | static-cloud | 断链 | simple | cloud-model | 合成标签完成 | 0.0% | 0.0% | 0.0 | 0.0 | 0.79 | 0.79 | None | None | 1 |
| P4 全网断链 | static-cloud | 断链 | complex | cloud-model | 合成标签完成 | 0.0% | 0.0% | 0.0 | 0.0 | 11.1 | 11.1 | None | None | 1 |
| P4 全网断链 | static-cloud | 断链 | safety | cloud-model | 合成标签完成 | 0.0% | 0.0% | 0.0 | 0.0 | 0.9 | 0.9 | None | None | 1 |

### 表 A 注 · 能力声明的来源

| 后端 | NLU 能力 | 声明来源 |
|---|---|---|
| cloud-model | 合成标签完成 | 桩合同（未实测模型准确率） |
| local-model | 合成标签完成 | 桩合同（未实测模型准确率） |
| local-rules | simple/safety 完成 | 计时代理合同，非完整 Dashboard 语义评测 |

P4 全网断链时，合成 complex 标签落到 `local-rules` 计时代理，接口成功率 100%、合同完成率 0%。这不是完整 Dashboard 的规则语义评测，不能推出任何真实模糊指令的完成率。

## 表 A2 · 按实际落到的后端聚合（唯一可比的口径）

跨任务类别取中位数会把亚毫秒的本地规则与数百毫秒的云端混在一起，没有可比性。下表按实际后端分组。

| 阶段 | 臂 | 实际后端 | n | 接口成功率 | 语义完成率 | 用户总时延中位 (ms) | 用户总时延最大 (ms) | 网络中位 (ms) | 服务端中位 (ms) |
|---|---|---|---|---|---|---|---|---|---|
| P1 链路正常 | adaptive | cloud-model | 1 | 100.0% | 100.0% | 418.1 | 418.1 | 51.6 | 300.6 |
| P1 链路正常 | adaptive | local-rules | 2 | 100.0% | 100.0% | 0.14 | 0.16 | 0.0 | 0.03 |
| P1 链路正常 | static-cloud | cloud-model | 3 | 100.0% | 100.0% | 338.8 | 342.9 | 38.3 | 300.3 |
| P2 WAN 劣化 | adaptive | local-model | 1 | 100.0% | 100.0% | 641.2 | 641.2 | 26.2 | 150.1 |
| P2 WAN 劣化 | adaptive | local-rules | 2 | 100.0% | 100.0% | 0.14 | 0.21 | 0.0 | 0.02 |
| P2 WAN 劣化 | static-cloud | cloud-model | 3 | 100.0% | 100.0% | 750.2 | 773.4 | 449.9 | 300.3 |
| P3 WAN 断链（LAN 尚存） | adaptive | local-model | 1 | 100.0% | 100.0% | 226.9 | 226.9 | 29.9 | 150.1 |
| P3 WAN 断链（LAN 尚存） | adaptive | local-rules | 2 | 100.0% | 100.0% | 0.14 | 0.17 | 0.0 | 0.02 |
| P3 WAN 断链（LAN 尚存） | static-cloud | cloud-model | 3 | 0.0% | 0.0% | None | None | None | None |
| P4 全网断链 | adaptive | local-rules | 3 | 100.0% | 66.7% | 0.08 | 22.7 | 0.0 | 0.01 |
| P4 全网断链 | static-cloud | cloud-model | 3 | 0.0% | 0.0% | None | None | None | None |

## 表 B · 决策分布（按原因）

| 阶段 | 臂 | 决策/原因 | 次数 |
|---|---|---|---|
| P1 链路正常 | adaptive | cloud-model/WAN_OK | 1 |
| P1 链路正常 | adaptive | local-rules/TASK_IS_SAFETY | 1 |
| P1 链路正常 | adaptive | local-rules/TASK_IS_SIMPLE | 1 |
| P1 链路正常 | static-cloud | cloud-model/STATIC_COMPILE_TIME | 3 |
| P2 WAN 劣化 | adaptive | local-model/WAN_RTT_HIGH | 1 |
| P2 WAN 劣化 | adaptive | local-rules/TASK_IS_SAFETY | 1 |
| P2 WAN 劣化 | adaptive | local-rules/TASK_IS_SIMPLE | 1 |
| P2 WAN 劣化 | static-cloud | cloud-model/STATIC_COMPILE_TIME | 3 |
| P3 WAN 断链（LAN 尚存） | adaptive | local-model/WAN_UNREACHABLE | 1 |
| P3 WAN 断链（LAN 尚存） | adaptive | local-rules/TASK_IS_SAFETY | 1 |
| P3 WAN 断链（LAN 尚存） | adaptive | local-rules/TASK_IS_SIMPLE | 1 |
| P3 WAN 断链（LAN 尚存） | static-cloud | cloud-model/STATIC_COMPILE_TIME | 3 |
| P4 全网断链 | adaptive | local-rules/LAN_DOWN | 1 |
| P4 全网断链 | adaptive | local-rules/TASK_IS_SAFETY | 1 |
| P4 全网断链 | adaptive | local-rules/TASK_IS_SIMPLE | 1 |
| P4 全网断链 | static-cloud | cloud-model/STATIC_COMPILE_TIME | 3 |

## 表 C · 探测开销与失败率交叉核对（自适应臂独有）

| 阶段 | 探测次数 | 探测中位 (ms) | 注入失败率 | 实测失败率 |
|---|---|---|---|---|
| P1 链路正常 | 1 | 65.7 | 0.0% | 0.0% |
| P2 WAN 劣化 | 1 | 464.7 | 10.0% | 0.0% |
| P3 WAN 断链（LAN 尚存） | 1 | 46.8 | 100.0% | 100.0% |
| P4 全网断链 | 1 | 22.6 | 100.0% | 100.0% |

> 探测是自适应策略自身的成本，静态方案不付这笔钱；仅统计实际执行探测的复杂任务，不含本地快速路径的零值和 8 次预热采样

> ⚠️ 实测失败率是**小样本比例**（n 见「探测次数」一列），二项分布下置信区间很宽：以 n=60、真实失败率 10% 为例，观察到 2～10 次失败都落在 95% 区间内。此列只用于**核对「注入是否真的生效」**，不足以作为失败率的精确估计，更不能拿来反推链路的丢包特性。

## 表 C2 · 失败构成对账（注入 vs 观测 vs 台架自身）

模拟器计数包含探测与业务连接，台架观测失败只统计业务请求；二者不能直接相等。逐请求的 `replay_outcome` 与 `probe_replay` 保存在 JSON 的 `raw_runs` 中，可分别复核注入的业务与探测失败。

| 阶段 | 臂 | 台架观测失败 | 模拟器拒绝连接 | 模拟器接受连接 | 失败类型 |
|---|---|---|---|---|---|
| P1 链路正常 | adaptive | 0/3 | 0 | 2 | — |
| P1 链路正常 | static-cloud | 0/3 | 0 | 3 | — |
| P2 WAN 劣化 | adaptive | 0/3 | 0 | 1 | — |
| P2 WAN 劣化 | static-cloud | 0/3 | 0 | 3 | — |
| P3 WAN 断链（LAN 尚存） | adaptive | 0/3 | 1 | 0 | — |
| P3 WAN 断链（LAN 尚存） | static-cloud | 3/3 | 3 | 0 | ConnectionAbortedError×1、ConnectionResetError×2 |
| P4 全网断链 | adaptive | 0/3 | 1 | 0 | UNRESOLVED_NO_NLU×1 |
| P4 全网断链 | static-cloud | 3/3 | 3 | 0 | ConnectionAbortedError×1、ConnectionResetError×2 |

> 静态臂计分段没有探测，业务失败可与 WAN 拒绝连接数核对。自适应臂另有探测流量，应按 `raw_runs` 的请求角色分开复核；不能把全部 WAN 拒绝都解释成业务请求失败。

## 表 D · 链路劣化 → 恢复 全过程决策轨迹

`复杂 NLU` 任务在链路逐步劣化再恢复时的档位变化。
注意平滑滞后：RTT 突变后档位不会立刻跟随，这是 α=1/8 的固有代价。

| 步骤 | 第几次探测 | 配置 RTT | 实测 RTT | 平滑后档位 | 原因 | 安全任务档位 |
|---|---|---|---|---|---|---|

## 已知局限（本台架测出来的，不是推测）

1. **恢复慢于劣化。** 平滑常数 α=1/8 对劣化与恢复一视同仁，于是断链恢复后要几十次探测才重新上云（见表 D 滞后摘要）。家庭场景里这表现为「网早就好了，系统还在用降级档」。**补救方向**：对「恢复方向」用更大的 α（非对称平滑），或在连续 k 次探测达标后直接跳档。**本版本未实现**，留作后续工作。
2. **单次瞬时失败代价偏大。** 平滑丢包率在 0 的状态下遇到一次失败即抬到 12%，而阈值为 5%，需要约 7 个样本才回落 —— 即一次网络抖动会换来约 7 次探测的降级。这是 EWM 的固有性质。
3. **模型耗时是桩参数，不是实测。** 见 §口径。所有涉及「云端更聪明」的论断在本次测量中都未获验证。
4. **样本量小。** 每个任务类别每档 n=20，只支持量级结论；模型耗时仍是桩参数时，不得把用户总时延差异表述成模型实测收益。

## 口径

- **真实测量**：用户总时延（探测 + 策略 + 后端段）、网络时延（后端段 − 服务端处理）、服务端 HTTP 处理耗时、连接失败率、探测时延与失败率。这些数字来自本机真实 TCP 往返，经 `link_emulator.py` 时延模型注入传播时延。
- **桩参数（非测量）**：模型推理耗时（cloud 300 ms / gateway 150 ms）。本机无 API key、未安装 Ollama，无法真跑模型；该值由命令行注入。
- **时延模型**：每方向首个数据块延迟 rtt/2，一条请求-应答净增约 rtt。是传播时延的近似模型，不是物理信道仿真。
- **失败注入**：模拟器按概率直接断开连接（应用层连接级失败），不是分组级丢包。TCP 分组级丢包会表现为重传时延，本台架不模拟那一层。
- **决策来源**：全部来自 `offload_policy.c`（经 `policy_cli` 常驻进程）。本测量脚本不实现任何卸载判据。
- **配对回放**：每个请求索引分别保存 WAN/LAN 与 probe/infer 的具体 RTT 和拒绝结果；两臂业务请求消费同一索引的结果，额外探测不会移动业务随机流。实际墙钟仍包含操作系统调度噪声。
- **本地规则计时范围**：台架的 `rule-timing-proxy` 是合成小循环，只用于策略路径计时，不代表真实设备动作耗时。真实动作执行由 Dashboard 路径另行验证。
