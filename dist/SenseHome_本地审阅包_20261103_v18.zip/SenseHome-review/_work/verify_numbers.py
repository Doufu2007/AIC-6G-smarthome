# -*- coding: utf-8 -*-
"""提交前的双向数字门。

结果 JSON 是实验事实源，作品方案是承重叙述。这个检查器同时验证：
1. 结果包满足逐请求 trace/raw schema；
2. 每个保存的 summary 能由 raw_runs 重新计算；
3. 作品方案的 8 行复杂任务表与结果包逐格一致；
4. 探测和恢复数字与结果包一致。

它不把历史 run_A~F 当作当前证据，也不硬编码实验数字。
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from types import SimpleNamespace
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PROJECT = os.path.join(ROOT, "SenseHome-6G")
RESULTS = os.path.join(PROJECT, "net_offload", "results", "results.json")
MD = os.path.join(PROJECT, "作品方案_场景设计_v1.md")
sys.path.insert(0, os.path.join(PROJECT, "net_offload"))

from evidence import validate_results_schema  # noqa: E402
from offload_bench import recovery_stats, summarize  # noqa: E402


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def close(a: Any, b: Any, tol: float = 0.06) -> bool:
    return isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool) and math.isfinite(float(a)) and math.isfinite(float(b)) and abs(float(a) - float(b)) <= tol


def numeric(text: str) -> float | None:
    # 去掉比值中的单位/括号，取单个字段的第一个十进制数字。
    m = re.search(r"-?\d+(?:\.\d+)?", text.replace(",", ""))
    return float(m.group()) if m else None


def ratio(text: str) -> float | None:
    m = re.search(r"(\d+)\s*/\s*(\d+)", text)
    if not m or int(m.group(2)) == 0:
        return None
    return 100.0 * int(m.group(1)) / int(m.group(2))


def phase_from_label(label: str) -> str | None:
    return {
        "P1 正常": "P1-normal",
        "P2 劣化": "P2-degraded",
        "P3 WAN 断": "P3-wan-down",
        "P4 全断": "P4-all-down",
    }.get(label.strip())


def check_raw_recompute(data: dict[str, Any], errors: list[str]) -> None:
    stub = data.get("stub_parameters", {})
    args = SimpleNamespace(cloud_compute_ms=float(stub.get("cloud_compute_ms", 300.0)))
    stored = {(s.get("phase"), s.get("arm")): s for s in data.get("summaries", [])}
    raw = {(r.get("phase"), r.get("arm")): r for r in data.get("raw_runs", [])}
    expected_keys = {(p, a) for p in ("P1-normal", "P2-degraded", "P3-wan-down", "P4-all-down") for a in ("adaptive", "static-cloud")}
    if set(stored) != expected_keys:
        fail(errors, f"summaries coverage is {sorted(stored)}, expected all 8 phase/arm pairs")
    if set(raw) != expected_keys:
        fail(errors, f"raw_runs coverage is {sorted(raw)}, expected all 8 phase/arm pairs")
    for key in sorted(expected_keys):
        if key not in raw or key not in stored:
            continue
        recomputed = summarize(raw[key], args)
        if recomputed != stored[key]:
            # 给出最小的定位信息，避免输出整棵大型对象。
            for section in ("by_task", "overall", "errors", "n_failed"):
                if recomputed.get(section) != stored[key].get(section):
                    fail(errors, f"summary drift for {key}: section {section} differs from raw_runs")
            if all(recomputed.get(s) == stored[key].get(s) for s in ("by_task", "overall", "errors", "n_failed")):
                fail(errors, f"summary drift for {key}: object differs")


def check_solution_table(data: dict[str, Any], errors: list[str]) -> None:
    text = open(MD, encoding="utf-8").read()
    rows = []
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 8 and phase_from_label(cells[0]) and cells[1] in {"adaptive", "static-cloud"}:
            rows.append(cells)
    if len(rows) != 8:
        fail(errors, f"complex-result table has {len(rows)} data rows; expected exactly 8")
        return
    summaries = {(s["phase"], s["arm"]): s for s in data["summaries"]}
    seen = set()
    for cells in rows:
        phase = phase_from_label(cells[0])
        arm = cells[1]
        key = (phase, arm)
        seen.add(key)
        summary = summaries.get(key)
        if not summary:
            fail(errors, f"table row references missing result {key}")
            continue
        complex_ = summary["by_task"]["complex"]
        expected = [
            ratio(cells[3]),
            ratio(cells[4]),
            numeric(cells[5]),
            numeric(cells[6]),
            numeric(cells[7]),
        ]
        actual = [
            complex_["completion_pct"],
            complex_["semantic_pct"],
            complex_["total_user_median_ms"],
            complex_["probe_median_ms"],
            complex_["backend_median_ms"],
        ]
        labels = ["接口成功率", "语义完成率", "用户总时延", "探测时延", "后端时延"]
        for label, exp, act in zip(labels, expected, actual):
            if exp is None or not close(exp, act):
                fail(errors, f"{cells[0]}/{arm} {label}: document={exp!r}, results={act!r}")
    if seen != set(summaries):
        fail(errors, f"table coverage {sorted(seen)} differs from summary coverage {sorted(summaries)}")


def check_derived(data: dict[str, Any], errors: list[str]) -> None:
    probe = {p["phase"]: p for p in data.get("probe_overheads", [])}
    for phase in ("P1-normal", "P2-degraded", "P3-wan-down", "P4-all-down"):
        rows = [r for run in data["raw_runs"] if run["phase"] == phase and run["arm"] == "adaptive" for r in run["rows"]]
        actual = [r["probe_ms"] for r in rows if r.get("wan_probe_ok") is not None]
        if not actual or phase not in probe:
            fail(errors, f"missing probe overhead evidence for {phase}")
            continue
        actual_sorted = sorted(actual)
        n = len(actual_sorted)
        median = actual_sorted[n // 2] if n % 2 else (actual_sorted[n // 2 - 1] + actual_sorted[n // 2]) / 2.0
        if not close(round(median, 1), probe[phase].get("median_probe_ms"), 0.06):
            fail(errors, f"probe overhead drift for {phase}: rows={median}, field={probe[phase].get('median_probe_ms')}")
        if probe[phase].get("n_probes") != len(actual):
            fail(errors, f"probe count drift for {phase}")
    recovery = data.get("recovery")
    try:
        expected_recovery = recovery_stats(data.get("transition_trace", []))
    except (KeyError, TypeError):
        fail(errors, "recovery cannot be recomputed: invalid transition_trace")
        return
    if recovery != expected_recovery:
        fail(errors, f"recovery drift from transition_trace: stored={recovery!r}, recomputed={expected_recovery!r}")
    if expected_recovery is not None:
        if not isinstance(recovery, dict):
            return
        if type(recovery.get("recovered")) is not bool:
            fail(errors, "recovery.recovered must be boolean")
        for field in ("probes_to_leave", "probes_after_blackout_to_cloud", "probes_to_recover", "total_probes"):
            value = recovery.get(field)
            if value is not None and (type(value) is not int or value < 0):
                fail(errors, f"recovery.{field} invalid")


def main() -> int:
    global MD
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=RESULTS)
    ap.add_argument("--solution", default=MD)
    args = ap.parse_args()
    MD = os.path.abspath(args.solution)
    data = json.load(open(args.results, encoding="utf-8"))
    errors: list[str] = []
    errors.extend(validate_results_schema(data))
    check_raw_recompute(data, errors)
    check_solution_table(data, errors)
    check_derived(data, errors)
    if errors:
        print("[FAIL] verify_numbers")
        for error in errors:
            print(" - " + error)
        return 1
    print("[OK] results schema, raw summary recomputation, 8-row solution table, probe and recovery recomputation agree")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
