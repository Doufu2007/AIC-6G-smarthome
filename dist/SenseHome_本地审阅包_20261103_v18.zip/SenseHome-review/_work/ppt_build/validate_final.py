﻿from pathlib import Path
import hashlib,json,zipfile,fitz
from pptx import Presentation
files=list(Path('dist/final').glob('*.pptx'))+list(Path('dist/final').glob('*.pdf'))
info=[]
for p in files: info.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
pptx=next(Path('dist/final').glob('*.pptx')); prs=Presentation(str(pptx)); pdf=next(Path('dist/final').glob('*.pdf'))
bad=[]
for i,s in enumerate(prs.slides,1):
 for j,sh in enumerate(s.shapes,1):
  if sh.left<0 or sh.top<0 or sh.left+sh.width>prs.slide_width or sh.top+sh.height>prs.slide_height: bad.append([i,j])
report={'toolchain':'PowerPoint COM (WithWindow=False) -> PDF SaveAs type 32; PowerPoint PNG Export + PyMuPDF PDF-page rendering','pptx_slides':len(prs.slides),'pdf_pages':len(fitz.open(pdf)),'pdf_png_count':len(list(Path('_work/ppt_render/pdf_png').glob('slide-*.png'))),'powerpoint_png_count':len(list(Path('_work/ppt_render').glob('*.PNG'))),'geometry_out_of_bounds':bad,'com_text_fit_issues':json.loads(Path('_work/ppt_render/text_fit_after.json').read_text(encoding='utf-8')),'visual_review':'13 pages individually inspected at 1600 px wide; slide 7 label overlap repaired by geometry only; no remaining clipping/overlap observed','content_boundary':'PC/QEMU/TCP simulation evidence only; real models/6G radio/physical actuators remain pending','remaining_placeholders':['slide 13 contact','slide 13 project entry'],'artifacts':info}
Path('_work/ppt_render/validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
