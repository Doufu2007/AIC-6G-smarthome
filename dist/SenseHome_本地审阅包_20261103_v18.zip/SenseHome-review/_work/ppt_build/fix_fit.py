﻿from pptx import Presentation
from pptx.util import Inches,Pt
from pathlib import Path
import json,shutil
p=next(Path('dist/final').glob('*.pptx')); b=Path('_work/ppt_build/original_before_fit.pptx'); shutil.copy2(p,b)
prs=Presentation(str(p)); issues=json.loads(Path('_work/ppt_render/text_fit_before.json').read_text(encoding='utf-8'))
for issue in issues:
 if issue['slide']==7: continue
 sh=prs.slides[issue['slide']-1].shapes[issue['shape']-1]
 # These are textboxes with transparent fill. Give glyphs enough physical height
 # without changing the original font or moving their baseline.
 sh.height=max(sh.height, Pt(issue['bound'][1]+4))
 if issue['text']=='→': sh.width=max(sh.width,Pt(issue['bound'][0]+5))
s=prs.slides[6]
for k,(ai,si) in enumerate([(10,11),(15,16),(20,21),(25,26)]):
 y=1.65+k*1.08
 a=s.shapes[ai-1]; a.left=Inches(9.7); a.top=Inches(y-0.03); a.width=Inches(2.78); a.height=Inches(.35)
 static=s.shapes[si-1]; static.left=Inches(9.7); static.top=Inches(y+.36); static.width=Inches(2.78); static.height=Inches(.32)
 for run in static.text_frame.paragraphs[0].runs: run.font.size=Pt(12)
# The orange footer is one line; the glyph height needs 18 pt.
s.shapes[27].height=Inches(.30)
prs.save(p)
print('fixed geometry',p)
