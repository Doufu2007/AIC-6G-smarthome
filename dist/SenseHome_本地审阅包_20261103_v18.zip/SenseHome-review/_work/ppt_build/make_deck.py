﻿from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR
from pathlib import Path

OUT = Path('dist/final/SenseHome_6G_场景设计答辩.pptx')
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank = prs.slide_layouts[6]
# Palette
NAVY = RGBColor(10, 27, 45)
INK = RGBColor(20, 37, 53)
TEAL = RGBColor(0, 150, 145)
CYAN = RGBColor(36, 185, 191)
MINT = RGBColor(222, 247, 244)
ORANGE = RGBColor(242, 147, 65)
RED = RGBColor(205, 75, 76)
BG = RGBColor(246, 249, 251)
WHITE = RGBColor(255,255,255)
GRAY = RGBColor(88, 105, 120)
LIGHT = RGBColor(225, 234, 239)
FONT = 'Microsoft YaHei'


def tx(slide, text, x, y, w, h, size=20, color=INK, bold=False, align=PP_ALIGN.LEFT, valign=MSO_ANCHOR.TOP, font=FONT):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame; tf.clear(); tf.word_wrap = True; tf.margin_left=Pt(2); tf.margin_right=Pt(2); tf.margin_top=Pt(1); tf.margin_bottom=Pt(1); tf.vertical_anchor=valign
    p = tf.paragraphs[0]; p.alignment = align
    run = p.add_run(); run.text = text; run.font.name=font; run.font.size=Pt(size); run.font.bold=bold; run.font.color.rgb=color
    return box

def rich(slide, runs, x,y,w,h,size=20,align=PP_ALIGN.LEFT):
    box=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h)); tf=box.text_frame; tf.clear(); tf.word_wrap=True; tf.margin_left=Pt(2); tf.margin_right=Pt(2)
    p=tf.paragraphs[0]; p.alignment=align
    for text,color,bold in runs:
        r=p.add_run(); r.text=text; r.font.name=FONT; r.font.size=Pt(size); r.font.color.rgb=color; r.font.bold=bold
    return box

def rect(slide,x,y,w,h,fill, line=None, radius=False):
    shape=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE, Inches(x),Inches(y),Inches(w),Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb=fill
    shape.line.color.rgb = line or fill
    if radius:
        try: shape.adjustments[0]=0.08
        except: pass
    return shape

def base(slide, num, title, subtitle=None, dark=False):
    slide.background.fill.solid(); slide.background.fill.fore_color.rgb = NAVY if dark else BG
    if not dark:
        rect(slide,0,0,13.333,0.12,TEAL)
        tx(slide,title,0.65,0.38,12.0,0.55,size=30,color=INK,bold=True)
        if subtitle: tx(slide,subtitle,0.67,0.98,12.0,0.34,size=12,color=GRAY)
        rect(slide,0.55,7.10,12.25,0.012,LIGHT)
        tx(slide,f'SenseHome · 场景设计 · {num:02d}',0.65,7.16,4.5,0.18,size=9,color=GRAY)
        tx(slide,'证据口径：PC/QEMU/TCP 链路模拟；真实模型、6G 空口与物理设备待验证',5.2,7.16,7.45,0.18,size=9,color=GRAY,align=PP_ALIGN.RIGHT)
    else:
        rect(slide,0.65,0.6,0.9,0.08,TEAL)
        tx(slide,f'{num:02d}',0.65,0.78,1.0,0.35,size=16,color=CYAN,bold=True)
        tx(slide,title,0.65,1.52,11.5,0.85,size=38,color=WHITE,bold=True)
        if subtitle: tx(slide,subtitle,0.7,2.45,11.0,0.55,size=18,color=RGBColor(186,210,219))

def bullet(slide, text, x,y,w,h, size=18, color=INK, bullet_color=TEAL):
    rect(slide,x,y,0.07,0.07,bullet_color)
    tx(slide,text,x+0.18,y-0.07,w-0.18,h,size=size,color=color)

def add_table(slide, data, x,y,w,h, widths=None, header=True, font_size=13):
    rows=len(data); cols=len(data[0]); table=slide.shapes.add_table(rows,cols,Inches(x),Inches(y),Inches(w),Inches(h)).table
    if widths:
        for i,v in enumerate(widths): table.columns[i].width=Inches(v)
    for r in range(rows):
        for c in range(cols):
            cell=table.cell(r,c); cell.text=str(data[r][c]); cell.margin_left=Pt(5); cell.margin_right=Pt(5); cell.margin_top=Pt(3); cell.margin_bottom=Pt(3)
            cell.fill.solid(); cell.fill.fore_color.rgb = NAVY if (header and r==0) else (WHITE if r%2 else RGBColor(239,246,248))
            for p in cell.text_frame.paragraphs:
                p.alignment=PP_ALIGN.LEFT
                for run in p.runs:
                    run.font.name=FONT; run.font.size=Pt(font_size); run.font.color.rgb=WHITE if (header and r==0) else INK; run.font.bold=(header and r==0)
    return table

# 1 cover
s=prs.slides.add_slide(blank); base(s,1,'6G 链路自适应的家庭 AI 推理卸载系统','SenseHome · 场景设计答辩',dark=True)
rect(s,0.72,3.4,4.2,0.08,TEAL)
tx(s,'把链路状态变成家庭 AI 的运行时决策输入',0.72,3.72,10.8,0.62,size=25,color=WHITE,bold=True)
tx(s,'从“全有或全无”变成可解释的降级阶梯',0.72,4.47,10.8,0.45,size=20,color=RGBColor(190,220,224))
tx(s,'首届人工智能+6G青年创新创业专项赛｜场景设计',0.72,6.57,8.0,0.3,size=13,color=RGBColor(160,190,200))

# 2 problem
s=prs.slides.add_slide(blank); base(s,2,'真实业务问题','面向中小型智能家居集成服务商的可预期服务水平')
rect(s,0.72,1.48,11.9,0.72,RGBColor(231,240,244),line=LIGHT,radius=True)
tx(s,'用户说“有点冷”时，网络状态变化，控制入口如何保持可用？',1.0,1.68,11.4,0.32,size=22,color=NAVY,bold=True,align=PP_ALIGN.CENTER)
# failure chain
for i,(label,sub) in enumerate([('设备','传感器与执行器'),('家庭网关','规则 / 策略 / 本地模型'),('WAN / 6G','时延、丢包、断链'),('云端模型','复杂自然语言')]):
    x=0.9+i*3.05; rect(s,x,3.0,2.2,1.15,WHITE,line=LIGHT,radius=True); tx(s,label,x+0.15,3.22,1.9,0.3,size=20,color=TEAL,bold=True,align=PP_ALIGN.CENTER); tx(s,sub,x+0.15,3.66,1.9,0.3,size=12,color=GRAY,align=PP_ALIGN.CENTER)
    if i<3: tx(s,'→',x+2.35,3.34,0.55,0.4,size=28,color=ORANGE,bold=True,align=PP_ALIGN.CENTER)
bullet(s,'广域网劣化会把自然语言请求一起拖慢或拖死',0.95,5.0,5.5,0.38,size=18)
bullet(s,'集成商需要可解释的降级路径，而不是单一云端开关',0.95,5.55,6.5,0.38,size=18)

# 3 boundaries
s=prs.slides.add_slide(blank); base(s,3,'场景边界与证据边界','先把“已验证”和“待验证”分开')
rect(s,0.85,1.55,5.7,4.65,MINT,line=TEAL,radius=True); tx(s,'已完成',1.15,1.88,4.8,0.4,size=24,color=TEAL,bold=True)
for i,t in enumerate(['端到端网关接线','C 策略作为唯一决策实现','四档链路台架与 480 条记录','故障回退、安全白名单、可复现构建']): bullet(s,t,1.2,2.55+i*0.7,4.8,0.4,size=17)
rect(s,6.8,1.55,5.7,4.65,RGBColor(255,246,235),line=ORANGE,radius=True); tx(s,'待验证',7.1,1.88,4.8,0.4,size=24,color=ORANGE,bold=True)
for i,t in enumerate(['真实云端 / 网关模型语义精度','真实 5G / 6G 空口与网络切片','真实家庭试点与物理执行器','采购成本与规模化压力']): bullet(s,t,7.15,2.55+i*0.7,4.8,0.4,size=17,bullet_color=ORANGE)

# 4 architecture
s=prs.slides.add_slide(blank); base(s,4,'总体架构','策略层位于家庭网关，观测、决策、执行各自留痕')
# arrows and boxes
nodes=[('设备与传感器','LAN'),('家庭网关','规则引擎\n策略 C\n可选本地模型'),('WAN / 6G','RTT / 丢包 / 可达性'),('云模型','复杂 NLU')]
for i,(a,b) in enumerate(nodes):
    x=0.8+i*3.1; rect(s,x,2.2,2.35,1.55,WHITE,line=TEAL if i==1 else LIGHT,radius=True); tx(s,a,x+0.12,2.52,2.1,0.3,size=20,color=TEAL if i==1 else INK,bold=True,align=PP_ALIGN.CENTER); tx(s,b,x+0.12,3.0,2.1,0.55,size=13,color=GRAY,align=PP_ALIGN.CENTER)
    if i<3: tx(s,'→',x+2.42,2.75,0.5,0.4,size=28,color=ORANGE,bold=True,align=PP_ALIGN.CENTER)
rect(s,3.9,4.35,5.0,0.72,MINT,line=TEAL,radius=True); tx(s,'offload_policy.c：唯一决策实现',4.1,4.56,4.6,0.25,size=18,color=TEAL,bold=True,align=PP_ALIGN.CENTER)
tx(s,'Python 网关只负责观测传递、后端调用、动作白名单和事件记录',1.25,5.5,10.8,0.35,size=18,color=NAVY,bold=True,align=PP_ALIGN.CENTER)

# 5 decision table
s=prs.slides.add_slide(blank); base(s,5,'七行决策表','任务类型先定安全边界，链路与算力再决定候选后端')
data=[['任务','WAN / LAN 状态','后端','原因'],['安全关键','任意','local-rules','TASK_IS_SAFETY'],['结构化控制','任意','local-rules','TASK_IS_SIMPLE'],['复杂 NLU','WAN 达标','cloud-model','WAN_OK'],['复杂 NLU','WAN 劣化、LAN 可用','local-model','WAN_RTT_HIGH / WAN_UNREACHABLE'],['复杂 NLU','LAN 不可达','local-rules','LAN_DOWN'],['任意','模型不可用或超载','降级一级','计算健康约束']]
add_table(s,data,0.72,1.45,11.95,4.85,widths=[2.05,3.15,2.0,4.75],font_size=13)
tx(s,'安全任务不因网络状态变化而放宽白名单。',0.85,6.48,7.5,0.3,size=17,color=RED,bold=True)

# 6 dashboard
s=prs.slides.add_slide(blank); base(s,6,'端到端 Dashboard','展示真实 /api/command 路径的可观测字段')
# mock dashboard
rect(s,0.82,1.45,11.75,4.95,WHITE,line=LIGHT,radius=True)
rect(s,1.05,1.7,11.3,0.45,NAVY); tx(s,'SenseHome Gateway   ·   /api/command',1.25,1.81,7,0.2,size=14,color=WHITE,bold=True)
fields=[('命令','客厅有点暗'),('任务类型','complex_nlu'),('链路','WAN degraded / LAN up'),('候选算力','local-model'),('原因码','WAN_RTT_HIGH'),('用户总时延','596.2 ms（台架）'),('动作','light_control / 客厅 / 60%'),('事件 ID','evt_20261103_00041')]
for i,(k,v) in enumerate(fields):
    col=i%2; row=i//2; x=1.2+col*5.35; y=2.45+row*0.78; tx(s,k,x,y,1.3,0.25,size=13,color=GRAY,bold=True); tx(s,v,x+1.35,y,3.7,0.3,size=16,color=INK,bold=(k in ['候选算力','原因码']))
tx(s,'当前闭环：真实 HTTP 假上游 → C 策略 → 白名单 → PC 模拟 JSON 状态；仍无真实模型与物理执行器。',1.1,5.95,11.0,0.28,size=12,color=ORANGE,align=PP_ALIGN.CENTER)

# 7 experiment
s=prs.slides.add_slide(blank); base(s,7,'四档台架实验','同一 trace 条件下比较 adaptive 与 static-cloud')
# bars
phases=[('P1 正常',405.6,346.4),('P2 劣化',596.2,725.6),('P3 WAN 断',195.0,None),('P4 全断',29.6,None)]
maxv=800
for i,(name,a,b) in enumerate(phases):
    y=1.65+i*1.08; tx(s,name,0.9,y,1.3,0.28,size=15,color=INK,bold=True)
    rect(s,2.25,y+0.02,7.2,0.25,LIGHT)
    rect(s,2.25,y+0.02,7.2*a/maxv,0.25,TEAL)
    tx(s,f'adaptive {a:.1f} ms',9.7,y-0.02,1.5,0.28,size=14,color=TEAL,bold=True)
    if b is not None: tx(s,f'static {b:.1f} ms',11.1,y-0.02,1.4,0.28,size=14,color=GRAY)
    else: tx(s,'static-cloud 接口 0/20',10.9,y-0.02,1.6,0.28,size=12,color=RED,bold=True)
rect(s,0.92,6.2,11.5,0.55,RGBColor(255,246,235),line=ORANGE,radius=True); tx(s,'480 条原始业务记录可追溯；P4 复杂语义 0/20 是桩合同，不是模型精度测量。',1.15,6.37,11.0,0.2,size=14,color=ORANGE,bold=True,align=PP_ALIGN.CENTER)

# 8 replay
s=prs.slides.add_slide(blank); base(s,8,'结果如何复核','从 trace 到事件 JSONL，每条结论都能回放')
for i,(title,desc) in enumerate([('paired_traces','每档 trace ID、seed、样本条件'),('events.jsonl','event_id、reason、fallback_from、interface_ok'),('evidence.py','校验 meta、桩参数、summary、来源标签')]):
    x=0.9+i*4.1; rect(s,x,2.05,3.55,2.25,WHITE,line=TEAL,radius=True); tx(s,str(i+1).zfill(2),x+0.25,2.3,0.5,0.3,size=16,color=TEAL,bold=True); tx(s,title,x+0.25,2.75,3.0,0.32,size=19,color=INK,bold=True); tx(s,desc,x+0.25,3.35,3.0,0.65,size=14,color=GRAY)
    if i<2: tx(s,'→',x+3.62,2.82,0.35,0.4,size=25,color=ORANGE,bold=True)
tx(s,'复核重点：不要把桩参数、接口成功和语义完成混成一个“准确率”。',1.1,5.4,11.0,0.35,size=19,color=NAVY,bold=True,align=PP_ALIGN.CENTER)

# 9 faults
s=prs.slides.add_slide(blank); base(s,9,'故障与安全','失败时回到更低一级，并留下结构化错误')
left=['模型进程退出','上游超时','畸形 JSON','远端危险动作','prompt injection','32 路并发 policy CLI']
rect(s,0.85,1.55,5.5,4.65,WHITE,line=LIGHT,radius=True); tx(s,'已测故障注入',1.15,1.9,4.5,0.35,size=23,color=TEAL,bold=True)
for i,t in enumerate(left): bullet(s,t,1.2,2.55+i*0.53,4.6,0.3,size=16)
rect(s,6.8,1.55,5.65,4.65,RGBColor(255,246,235),line=ORANGE,radius=True); tx(s,'安全边界',7.1,1.9,4.7,0.35,size=23,color=ORANGE,bold=True)
for i,t in enumerate(['local-rules 继续接管','危险动作不进入白名单','fallback 自身异常也记录失败事件','真实设备联锁仍需验证']): bullet(s,t,7.15,2.55+i*0.72,4.7,0.35,size=16,bullet_color=ORANGE)

# 10 6G value
s=prs.slides.add_slide(blank); base(s,10,'资源协同与 6G 价值','AI 与网络状态在网关处形成可观测闭环')
rect(s,0.9,1.6,5.55,4.5,MINT,line=TEAL,radius=True); tx(s,'AI 赋能 6G',1.2,1.95,4.5,0.35,size=24,color=TEAL,bold=True)
for i,t in enumerate(['端侧先行路由，减少不必要的上云请求','为推理负载标记任务类别与优先级','支持的开关灯与只读查询绕过同步探测']): bullet(s,t,1.2,2.65+i*0.82,4.7,0.48,size=17)
rect(s,6.85,1.6,5.55,4.5,WHITE,line=LIGHT,radius=True); tx(s,'6G 赋能 AI',7.15,1.95,4.5,0.35,size=24,color=NAVY,bold=True)
for i,t in enumerate(['确定性承载为云侧推理提供预算输入','链路状态进入运行时决策，而非静态配置','网络切片与空天地协同待真实网络阶段']): bullet(s,t,7.15,2.65+i*0.82,4.7,0.48,size=17,bullet_color=ORANGE)
tx(s,'Dashboard 独立模拟证据：160 次请求，开关灯 p95 ≤ 4.434 ms，安防只读 p95 ≤ 1.711 ms。',1.0,6.45,11.3,0.28,size=14,color=GRAY,align=PP_ALIGN.CENTER)

# 11 cost
s=prs.slides.add_slide(blank); base(s,11,'成本与部署','先把端侧策略做小，再按模型需求配置网关')
add_table(s,[['层级','实现','当前证据'],['端侧策略','纯 C，目标对象 text+data+bss 约 28.1 KB','历史宿主 size 记录'],['家庭网关','Python 网关 + 动作白名单','PC/QEMU/TCP 闭环'],['模型服务','AutoDL 顺序验收小、大模型','真实模型结果待接入'],['规模化','设备压力与采购成本','尚未测量']],0.85,1.55,11.6,3.6,widths=[2.1,4.1,5.4],font_size=14)
rect(s,1.1,5.65,11.1,0.65,RGBColor(255,246,235),line=ORANGE,radius=True); tx(s,'不承诺十元级模型网关，也不把单卡顺序实验写成双地端云部署。',1.35,5.86,10.6,0.23,size=16,color=ORANGE,bold=True,align=PP_ALIGN.CENTER)

# 12 next
s=prs.slides.add_slide(blank); base(s,12,'局限与下一步','把未验证项变成下一轮可验收的工作包')
items=[('当前瓶颈','P2 complex 探测中位 425.5 ms；K1/K2 原目标未达'),('真实模型','AutoDL 输出 p50/p95、动作正确率与失败原因'),('系统补证','需求、资源、外部网络、目标设备移植'),('安全边界','燃气、门禁等未授权控制始终拒绝执行')]
for i,(a,b) in enumerate(items):
    y=1.55+i*1.05; rect(s,0.9,y,2.2,0.62,NAVY,radius=True); tx(s,a,1.05,y+0.18,1.9,0.23,size=16,color=WHITE,bold=True,align=PP_ALIGN.CENTER); tx(s,b,3.4,y+0.16,8.9,0.3,size=17,color=INK)
tx(s,'所有新增数字先回填 evidence schema，再进入方案正文。',1.1,6.2,11.1,0.35,size=19,color=TEAL,bold=True,align=PP_ALIGN.CENTER)

# 13 close
s=prs.slides.add_slide(blank); base(s,13,'6G 链路自适应的家庭 AI 推理卸载系统','SenseHome · 场景设计',dark=True)
rect(s,0.75,3.35,3.0,0.08,TEAL)
tx(s,'把可用性、语义能力和安全边界分档管理',0.75,3.75,11.5,0.6,size=27,color=WHITE,bold=True)
tx(s,'每次选择可解释、可回放、可回退',0.75,4.55,11.5,0.4,size=22,color=RGBColor(190,220,224))
tx(s,'联系方式：待补齐｜作品入口：待补齐',0.75,6.45,8.0,0.28,size=13,color=RGBColor(160,190,200))

prs.save(OUT)
print(OUT, OUT.stat().st_size)
