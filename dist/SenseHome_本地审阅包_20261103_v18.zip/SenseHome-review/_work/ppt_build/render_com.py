﻿from pathlib import Path
import win32com.client,pythoncom,json,fitz
p=next(Path('dist/final').glob('*.pptx')).resolve(); out=Path('_work/ppt_render').resolve(); pdf=p.with_suffix('.pdf')
pythoncom.CoInitialize(); app=win32com.client.DispatchEx('PowerPoint.Application'); pres=None;issues=[]
try:
 pres=app.Presentations.Open(str(p),True,False,False)
 for i in range(1,pres.Slides.Count+1):
  for j in range(1,pres.Slides.Item(i).Shapes.Count+1):
   sh=pres.Slides.Item(i).Shapes.Item(j)
   try:
    if sh.HasTextFrame and sh.TextFrame2.HasText:
     tr=sh.TextFrame2.TextRange; bw=float(tr.BoundWidth); bh=float(tr.BoundHeight); iw=float(sh.Width)-float(sh.TextFrame2.MarginLeft)-float(sh.TextFrame2.MarginRight); ih=float(sh.Height)-float(sh.TextFrame2.MarginTop)-float(sh.TextFrame2.MarginBottom)
     if bh>ih+1 or bw>iw+1: issues.append({'slide':i,'shape':j,'text':tr.Text,'bound':[bw,bh],'inner':[iw,ih]})
   except: pass
 pres.Export(str(out),'PNG',1600,900)
 pres.SaveAs(str(pdf),32)
finally:
 if pres:pres.Close()
 app.Quit();pythoncom.CoUninitialize()
Path('_work/ppt_render/text_fit_after.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2),encoding='utf-8')
print('text_fit_issues',len(issues)); print(json.dumps(issues,ensure_ascii=False)[:1000])
d=fitz.open(pdf); print('pdf_pages',len(d),'pdf_bytes',pdf.stat().st_size)
out2=out/'pdf_png';out2.mkdir(exist_ok=True)
for i,page in enumerate(d,1): page.get_pixmap(matrix=fitz.Matrix(1600/page.rect.width,1600/page.rect.width)).save(out2/f'slide-{i:02d}.png')
print('rendered',len(list(out2.glob('*.png'))))
