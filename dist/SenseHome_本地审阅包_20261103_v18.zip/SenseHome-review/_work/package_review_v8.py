"""Build the current local review archive from the workspace."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

import package_review

ROOT = package_review.ROOT
PACKAGE = ROOT / "dist" / "SenseHome_本地审阅包_20261103_v18.zip"
HASHES = PACKAGE.with_suffix(".sha256.json")
CHECKPOINT = ROOT / "docs/execution/2026-11-03-delivery-checkpoint.md"
VIDEO = ROOT / "dist/SenseHome_AI6G_演示视频_20261103_v2.mp4"


def select_files():
    selected = set(package_review.select_files())
    selected.update({Path(__file__).resolve(), CHECKPOINT})
    selected.update((ROOT / "docs").glob("real_model*.md"))
    selected.add(ROOT / "国一冲刺差距审计与升级方案.md")
    selected.update(ROOT / "_work" / name for name in (
        "verify_pdf.py", "run_final_checks.py", "pdf_toc_utils.py", "toc_titles.json",
        "toc_pages.json", "package_review.py", "import_autodl_evidence.py"))
    selected.add(ROOT / "_work/ppt_render/validation.json")
    selected.update((ROOT / "_work/ppt_build").glob("*.py"))
    for relative in ("_work/final_checks_20261103", "_work/final_checks_20261103b"):
        selected.update(path for path in (ROOT / relative).rglob("*")
                        if path.is_file() and path.suffix.lower() in {".json", ".md"})
    for relative in ("docs/deployment", "docs/evidence", "docs/video", "dist/final"):
        selected.update(path for path in (ROOT / relative).rglob("*")
                        if path.is_file() and "__pycache__" not in path.parts
                        and path.suffix.lower() in {".md", ".py", ".ps1", ".sh", ".txt", ".json", ".jsonl", ".pptx", ".pdf"})
    for path in (ROOT / "docs/experiments").rglob("*"):
        if path.is_file() and "quarantine_untrusted_reviewed" not in path.parts \
                and path.suffix.lower() in {".json", ".jsonl", ".md", ".txt", ".log"}:
            selected.add(path)
    selected.add(VIDEO)
    files = sorted(selected, key=lambda p: p.relative_to(ROOT).as_posix())
    missing = [str(p.relative_to(ROOT)) for p in files if not p.is_file()]
    if missing:
        raise SystemExit("Missing review artifacts: " + ", ".join(missing))
    forbidden = [p for p in files if p.name.startswith(".env") or ".private." in p.name
                 or p.suffix.lower() in {".wav", ".safetensors", ".pem", ".key"}]
    if forbidden:
        raise SystemExit("Private or heavyweight input selected: " + ", ".join(str(p.relative_to(ROOT)) for p in forbidden))
    return files


def main():
    if PACKAGE.exists() or HASHES.exists():
        raise SystemExit("Refusing to overwrite existing v18 snapshot")
    files = select_files()
    manifest = {p.relative_to(ROOT).as_posix(): {"bytes": p.stat().st_size,
                 "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
    readme = '# SenseHome 本地审阅快照（2026-11-03 v18）\n本包包含当前代码、本地台架与模拟设备证据、作品方案、答辩材料、演示视频及部署记录。本地审阅包，尚未上传或提交。当前交付状态以 docs/execution/2026-11-03-delivery-checkpoint.md 为准。\n\n20 条评测标签已由参赛者本人在本对话中逐条人工确认并冻结，正式数据集为 SenseHome-6G/net_offload/backends/eval_commands.reviewed.jsonl，冻结记录见 docs/deployment/20条动作标签冻结记录_20261103.json。docs/experiments/autodl_20261103_normalized_v2/eval.formal.json 是对已捕获真实模型响应的冻结后正式重新标注：20 条中 HTTP 成功 17 条、参考动作一致 17 条（85.0%），其中预期拒答 3/3。该报告明确记录 inference_rerun_after_freeze=false，表示冻结后没有重新调用模型，不能将重新标注描述为冻结后重新推理。\n\n评测 CLI 默认读取 reviewed 标签；原始 eval_commands.jsonl 仅保留为草案历史，只有显式 --allow-draft-labels 才能用于预检。AutoDL 小模型运行环境、模型 revision、权重哈希、原始逐条响应及失败/保护证据均保留在 docs/experiments；大模型暂无推理结果。外部 RTOS、工具链和模型权重不在包内。SHA256SUMS.json 列出所有归档文件哈希。\n'
    with zipfile.ZipFile(PACKAGE, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, "SenseHome-review/" + path.relative_to(ROOT).as_posix())
        archive.writestr("SenseHome-review/REVIEW_README.md", readme.encode("utf-8"))
        archive.writestr("SenseHome-review/SHA256SUMS.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    with zipfile.ZipFile(PACKAGE) as archive:
        if archive.testzip() is not None:
            raise SystemExit("ZIP CRC check failed")
        for relative, expected in manifest.items():
            raw = archive.read("SenseHome-review/" + relative)
            if len(raw) != expected["bytes"] or hashlib.sha256(raw).hexdigest() != expected["sha256"]:
                raise SystemExit("Archived file hash mismatch: " + relative)
    report = {"package": PACKAGE.name, "bytes": PACKAGE.stat().st_size,
              "sha256": hashlib.sha256(PACKAGE.read_bytes()).hexdigest(),
              "n_files": len(files) + 2, "zip_crc_and_all_file_hashes": "pass", "files": manifest}
    HASHES.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "files"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
